# C_PHY Open IP

MIPI C-PHY trio (3-wire, 3-level) symbol-transmitter with loopback decoder
Implementation scope:
* Trio wires a/b/c, each carrying one of three levels {low,mid,high},
simplified to a 2-bit per wire encoding (00=low, 01=mid, 10=high).
One symbol per clk cycle (real C-PHY maps ~2.28 bits/symbol at wire
rate; the clocked simplification is documented).
* Legal wire states: the five permutations of {low,mid,high} used as
data states S0..S4 (every symbol has three mutually distinct wire
levels). The sixth physical permutation X is reserved as the
collision marker described below. Idle/stop = all wires mid, which
never collides with a data symbol.
* 16-bit -> 7 symbol mapping (custom table, per task allowance; the TB
uses the identical table):
digits   : d_i = (v / 5**i) mod 5, i = 0..6 (5**7 = 78125 > 65535)
rotation : k_i = (d_i + i) mod 5         (position-dependent)
symbol_i : S[k_i], except when S[k_i] would equal the previous
transmitted symbol -- then the reserved marker X is sent
and the receiver recovers k_i = index(previous symbol).
This guarantees adjacent symbols always differ on the trio (a hard
C-PHY requirement) while keeping the mapping bijective. Note: with
only 5 legal states a change-constrained 16->7 mapping is
information-theoretically impossible (5*4^6 < 2^16); real C-PHY
therefore uses 6 states. Here the 6th state appears only as the
collision marker, documented simplification.
* Packet format: idle (mid,mid,mid) -> 7-symbol sync word
{S1,S3,S0,S2,S4,S1,X} (simplified; real C-PHY uses the "4444443"
sync sequence) -> 7 symbols per 16-bit payload word -> stop.
* RX decodes the same trio (TB loopback): sync match, symbol-to-digit
de-rotation, word reassembly. Protocol violations (illegal wire
state, adjacent identical symbols, bad sync, mid-word stop) raise
sticky irq.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/C_PHY_top.sv` -- synthesizable RTL (top: `C_PHY_top`)
- `tb/C_PHY_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/C_PHY_yosys.ys` -- Yosys synthesis script
- `syn/C_PHY_dc.tcl` -- Synopsys Design Compiler script
- `syn/C_PHY.sdc` -- timing constraints
- `sim/filelist_C_PHY.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
