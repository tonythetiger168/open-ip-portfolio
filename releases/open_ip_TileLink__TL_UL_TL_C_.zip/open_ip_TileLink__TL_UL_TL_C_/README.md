# TileLink__TL_UL_TL_C_ Open IP

TileLink TL-UL slave -- real protocol IP design
Scope : TileLink Uncached Lightweight (TL-UL) slave, A/D channels only.
NOTE: TL-C (cached, B/C/E channels) is NOT in scope of this IP.
PutFull(0)/PutPartial(1)/Get(4), size must be 2 (4B, bus width),
4B alignment check, mask/size consistency check, source echo,
unsupported opcode/size/range -> d_error + sticky irq,
64x32 regfile.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/TileLink__TL_UL_TL_C__top.sv` -- synthesizable RTL (top: `TileLink__TL_UL_TL_C__top`)
- `tb/TileLink__TL_UL_TL_C__tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/TileLink__TL_UL_TL_C__yosys.ys` -- Yosys synthesis script
- `syn/TileLink__TL_UL_TL_C__dc.tcl` -- Synopsys Design Compiler script
- `syn/TileLink__TL_UL_TL_C_.sdc` -- timing constraints
- `sim/filelist_TileLink__TL_UL_TL_C_.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
