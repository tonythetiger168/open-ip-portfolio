# USB Open IP

USB 1.1 Full-Speed device controller (EP0 control read + EP1 interrupt IN)
Implementation scope:
* PHY layer : NRZI decode/encode, bit stuffing (insert 0 after six 1s,
remove stuffed 0 on receive), SE0(2 bit)+J(1 bit) EOP,
dp/dm tri-state pads with output-enable
* Protocol  : SYNC field 8'h80 (KJKJKJKK), PID nibble-complement check,
token frame addr[7]+endp[4]+CRC5(poly 0x05),
data frame payload+CRC16(poly 0x8005),
handshakes ACK/NAK/STALL,
DATA0/DATA1 toggle synchronization (retransmit on lost ACK,
discard-but-ACK on duplicated data)
* Function  : EP0 GET_DESCRIPTOR (fixed 8-byte device descriptor),
EP1 interrupt IN (4-byte transfer counter),
SETUP data stage written into 8x8 register file
Line rate is parameterized: BIT_CLKS clk cycles per USB bit time.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/USB_top.sv` -- synthesizable RTL (top: `USB_top`)
- `tb/USB_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/USB_yosys.ys` -- Yosys synthesis script
- `syn/USB_dc.tcl` -- Synopsys Design Compiler script
- `syn/USB.sdc` -- timing constraints
- `sim/filelist_USB.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
