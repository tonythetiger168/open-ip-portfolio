# Crypto___Security_Engine Open IP

Crypto & Security Engine -- real SHA-256 (FIPS 180-4) + HMAC (RFC 2104).
* Full SHA-256 compression function, 64 rounds, 1 round/clk, K constant
table, on-the-fly message schedule
* Message port: 512-bit block written as 4x128 words + msg_len (bytes,
0..64); start triggers hashing; padding (0x80 || 0 || len64) is done
internally, including the 56..64-byte two-block corner case
* HMAC mode: 512-bit key block written as 4x128 words; ipad/opad and the
two-pass H(K^opad || H(K^ipad || msg)) are computed automatically
* digest[255:0] + done; any start/key/msg write while busy -> irq pulse
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/Crypto___Security_Engine_top.sv` -- synthesizable RTL (top: `Crypto___Security_Engine_top`)
- `tb/Crypto___Security_Engine_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/Crypto___Security_Engine_yosys.ys` -- Yosys synthesis script
- `syn/Crypto___Security_Engine_dc.tcl` -- Synopsys Design Compiler script
- `syn/Crypto___Security_Engine.sdc` -- timing constraints
- `sim/filelist_Crypto___Security_Engine.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
