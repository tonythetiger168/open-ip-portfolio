# CPRI_v8_0__eCPRI_over_CPR_ Open IP

CPRI v8.0 (eCPRI over CPR) -- CPRI master (REC) link-layer slice
- full 8b/10b encode/decode: all D0.0..D31.7 + K28.x, running disparity
(symbol = {a,b,c,d,e,i,f,g,h,j}, 'a' transmitted first, 1 symbol/clk)
- basic frame = 1 control word + 15 IQ words (16 bytes)
- hyperframe = 64 basic frames (simplified from 256 -- educational slice)
- sync FSM: master sends K28.5+0x50+0x50 at hyperframe start, peer RE
replies with K28.5; HUNT -> ALIGN (2 well-placed commas) -> SYNC,
rx phase locks onto the peer hyperframe
- control word slots: #0 sync (K28.5), #1 L1 inband (16-hyperframe slow
stream carrying rate / pointer-p / protocol-version negotiation),
#4 vendor byte
- IQ data: peer 16-bit I/Q interleaved byte stream packed into 32x32
buffer as {I[15:0],Q[15:0]} words, cpu port pop
- 8x8 rate config registers (cpu port)
- loss of sync: 4 consecutive hyperframes without peer K28.5 at the
expected position -> resync (HUNT) + irq
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/CPRI_v8_0__eCPRI_over_CPR__top.sv` -- synthesizable RTL (top: `CPRI_v8_0__eCPRI_over_CPR__top`)
- `tb/CPRI_v8_0__eCPRI_over_CPR__tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/CPRI_v8_0__eCPRI_over_CPR__yosys.ys` -- Yosys synthesis script
- `syn/CPRI_v8_0__eCPRI_over_CPR__dc.tcl` -- Synopsys Design Compiler script
- `syn/CPRI_v8_0__eCPRI_over_CPR_.sdc` -- timing constraints
- `sim/filelist_CPRI_v8_0__eCPRI_over_CPR_.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
