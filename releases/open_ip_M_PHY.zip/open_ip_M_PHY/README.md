# M_PHY Open IP

MIPI M-PHY lane (8b/10b, PWM-gear rates, HIBERN8) with loopback decoder
Implementation scope:
* 8b/10b codec, documented subset: D-codes D0.0..D7.0 (8'h00..8'h07)
plus control code K28.5 (8'hBC, comma). Encoding follows the standard
table with running-disparity (RD) tracking per 6b/4b sub-block; the
decoder accepts both RD forms, checks sub-block disparity alternation
and flags code / disparity violations on irq.
* PWM gears simplified to NRZ bit-rate division (real M-PHY TYPE-I uses
PWM pulse widths at LS gears; the gearing itself is kept): G1 = 1 bit
per clk, G2 = 1 bit per 2 clk, selected by the gear input. Gear may
only change while the lane is idle (documented host contract).
* Line states on tx_dif_p/tx_dif_n: DIF-N (0,1) = idle / bit 0,
DIF-P (1,0) = bit 1, DIF-Z (0,0) = high-Z during HIBERN8.
* HIBERN8: hibern8_req enters the SAVE state (hibern8 power-down flag
raised, lines DIF-Z); wake_req drives an 8-clk DIF-N wake burst and
returns to normal idle. RX detects DIF-Z persistence as hibernation
and re-hunts after wake.
* Bursts: K28.5 comma (bit 'a' first) for RX alignment, then 8b/10b
data words back-to-back; a 1-deep buffer keeps the stream seamless.
RX hunts for the comma (clk-resolution shift register, gear-aware),
then frames every 10 bits; an all-zero idle word ends the burst and
returns the RX to hunt.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/M_PHY_top.sv` -- synthesizable RTL (top: `M_PHY_top`)
- `tb/M_PHY_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/M_PHY_yosys.ys` -- Yosys synthesis script
- `syn/M_PHY_dc.tcl` -- Synopsys Design Compiler script
- `syn/M_PHY.sdc` -- timing constraints
- `sim/filelist_M_PHY.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
