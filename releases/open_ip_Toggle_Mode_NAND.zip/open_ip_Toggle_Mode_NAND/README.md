# Toggle_Mode_NAND Open IP

Toggle Mode NAND protocol IP -- NAND flash target (educational slice)
Implementation scope (documented simplified subset of ONFI/toggle NAND):
- 8-bit async command/address/data interface: ce_n/cle/ale/we_n/re_n,
dq[7:0] tri-state, rb_n ready/busy open-drain style output.
dqs echoes the re_n strobe during data output (toggle-mode flavour;
single-ended legacy timing is used for the transfers themselves).
- Command latch on rising edge of we_n while ce_n=0 & cle=1;
address latch while ale=1; data-in latch while cle=0 & ale=0.
- Command set:
0x90 + 1 addr byte        : Read ID, 5-byte ID on re_n strobes
0x00 + 5 addr + 0x30      : Page Read (col2+row3 address cycles,
col[5:0] = byte, row[3:0] = page)
0x80 + 5 addr + data + 0x10: Page Program (1->0 semantics)
0x60 + 3 addr + 0xD0      : Block Erase (4 pages per block)
0x70                      : Read Status (bit6 ready, bit0 fail)
0xFF                      : Reset (aborts anything, clears irq)
- Array model: 16 pages x 64 bytes; block = 4 pages. Block 3
(pages 12..15) is protected: program/erase set status fail bit.
- rb_n busy timing (clk cycles): read 25, program 200, erase 1000.
- Illegal command / out-of-sequence command -> ignored + sticky irq
(cleared by 0xFF reset or rst_n).
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/Toggle_Mode_NAND_top.sv` -- synthesizable RTL (top: `Toggle_Mode_NAND_top`)
- `tb/Toggle_Mode_NAND_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/Toggle_Mode_NAND_yosys.ys` -- Yosys synthesis script
- `syn/Toggle_Mode_NAND_dc.tcl` -- Synopsys Design Compiler script
- `syn/Toggle_Mode_NAND.sdc` -- timing constraints
- `sim/filelist_Toggle_Mode_NAND.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
