# HDMI_2_1 Open IP

HDMI_2_1 protocol Open IP -- HDMI source (TMDS mode) educational slice:
full TMDS 8b/10b encode algorithm (transition minimisation with XOR/XNOR
selection + disparity tracking + DC-balance bits 8/9), 3 data channels +
TMDS clock channel (serial 1 bit/clk simplification), control period with
8-pixel video/data-island preambles and CTL0-3 codes (4 fixed 10-bit
codes), video period RGB888 active pixels on 3 channels, data island
period with TERC4 4b/10b encoding and packet structure (24-bit header +
4 subpackets x 56 bit, BCH ECC simplified to XOR parity - see comments),
AVI InfoFrame (type 0x82) sent once per frame, built-in 640x480@60
timing generator (hact=640 hfp=16 hsw=96 hbp=48 / vact=480 vfp=10
vsw=2 vbp=33).
Open IP design implementation v2.3 -- Apache-2.0
----------------------------------------------------------------------------
Documented simplifications (educational slice of the HDMI physical layer):
- Serialisation is 1 bit/clk per channel (real TMDS runs 10x pixel clk);
pixel period = 10 clk, all 3 channels + clock channel in lock-step,
TMDS bit0 transmitted first. TMDS clock channel = 10'b1111100000
repeated (LSB first).
- Pixel source is an internal demo generator: R=x[7:0], G=y[7:0],
B=x[7:0]^y[7:0]. Sync polarity is positive logic (VGA 640x480 uses
negative; documented deviation), encoded {VSYNC,HSYNC} on channel 0
control bits, CTL1:0 on channel 1, CTL3:2 on channel 2.
- Data island: once per frame at line y=VACT+1, pixels x=0..43:
8 px preamble (CTL3=CTL2=1), 2 px leading guard band, 32 px data,
2 px trailing guard band. Header = {type,ver,len} + 1 XOR-parity byte
(BCH(32,24) simplified to XOR parity, NOT real ECC). Each subpacket =
56 data bits + 8 XOR-parity bits (BCH(64,56) simplified, NOT real ECC).
Bit map per island pixel i (0..31), TERC4 4-bit inputs:
ch0 = {VSYNC, HSYNC, 1'b0, header[i]}
ch1 = {sp1[2i+1], sp1[2i], sp0[2i+1], sp0[2i]}
ch2 = {sp3[2i+1], sp3[2i], sp2[2i+1], sp2[2i]}
- AVI InfoFrame: type=0x82 ver=0x02 len=0x0D, PB1=0x10 (RGB, active
info), PB2=0x10 (4:3 picture aspect), PB4=VIC=0x01 (640x480p60),
checksum = two's complement of byte sum (real HDMI rule).
- hpd=0: TMDS outputs stop (all zero), timing restarts at (0,0) on
hpd return; irq = level "link was running and hpd was lost".

## Package contents

- `rtl/HDMI_2_1_top.sv` -- synthesizable RTL (top: `HDMI_2_1_top`)
- `tb/HDMI_2_1_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/HDMI_2_1_yosys.ys` -- Yosys synthesis script
- `syn/HDMI_2_1_dc.tcl` -- Synopsys Design Compiler script
- `syn/HDMI_2_1.sdc` -- timing constraints
- `sim/filelist_HDMI_2_1.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
