# AHB Open IP

AHB-Lite slave -- address/data phase pipelined, BUSY/IDLE, wait states,
two-cycle ERROR response, 256x32 register file
Open IP design implementation v2.3 -- Apache-2.0
Address map (byte addresses):
0x000-0x3FF : fast region, zero wait state   (256 x 32 register file)
0x400-0x7FF : slow region, one wait state    (same register file)
0x800+      : reserved  -> two-cycle ERROR response + irq event

## Package contents

- `rtl/AHB_top.sv` -- synthesizable RTL (top: `AHB_top`)
- `tb/AHB_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/AHB_yosys.ys` -- Yosys synthesis script
- `syn/AHB_dc.tcl` -- Synopsys Design Compiler script
- `syn/AHB.sdc` -- timing constraints
- `sim/filelist_AHB.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
