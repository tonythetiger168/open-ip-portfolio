# SDIO Open IP

SDIO protocol Open IP -- SDIO card/slave (CMD52/CMD53, R5, CRC7/CRC16)
-- Apache-2.0
Open IP design implementation v2.4
Scope: card-side minimal SDIO subset.
* CMD line quasi-bidirectional: host drives while sending a command (card
Hi-Z), card drives during the R5 response. Sampled on sd_clk rising edge.
* Frame format: start(0) + tx(1=host/0=card) + cmdidx[6] + arg[32] +
CRC7[7] + end(1), 48 bits, MSB first.
* CMD52 IO_RW_DIRECT: arg[31]=r/w, arg[30:28]=func, arg[27]=raw,
arg[26]=stuff, arg[25:9]=addr[17], arg[8]=stuff, arg[7:0]=data.
Reads/writes the internal function-1 register file (128 x 8-bit) and
answers R5 (cmdidx=52, flags + read/write data + CRC7).
* CMD53 IO_RW_EXTENDED: arg[31]=r/w, arg[30:28]=func, arg[27]=block mode,
arg[26]=opcode (1=incrementing address), arg[25:9]=addr[17],
arg[8:0]=count. Byte mode only, 1..32 bytes (count==0 -> 32).
write: host shifts block on DAT0 (start + n*8 data bits + CRC16 + end),
card verifies CRC16 and commits the block only on match;
read : card drives block on DAT[3:0] (start 0000 + 2*n nibbles +
per-line CRC16 + end 1111).
* CRC7  poly 7'h09 (x^7+x^3+1), MSB-first, over frame bits [47:8].
* CRC16 poly 16'h1021 (CCITT), MSB-first, one instance per DAT line.
* Bad CRC7 / illegal command / bad CRC16 / missing end bit -> no response,
irq pulse of one sd_clk, transfer discarded.
Note: `clk` is the reserved system clock; the whole card datapath runs on
the sd_clk line clock (documented simplification; clk kept so the
port contract stays intact).

## Package contents

- `rtl/SDIO_top.sv` -- synthesizable RTL (top: `SDIO_top`)
- `tb/SDIO_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `tb/SDIO_bitclks_tb.sv` -- directed functional TB at BIT_CLKS=4 (make sim_bitclks)
- `syn/SDIO_yosys.ys` -- Yosys synthesis script
- `syn/SDIO_dc.tcl` -- Synopsys Design Compiler script
- `syn/SDIO.sdc` -- timing constraints
- `sim/filelist_SDIO.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
