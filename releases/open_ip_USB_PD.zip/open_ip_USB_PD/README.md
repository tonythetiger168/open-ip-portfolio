# USB_PD Open IP

USB-PD (USB Power Delivery) UFP / sink-side controller
Implementation scope:
* CC-line BMC (biphase-mark coding) encoder/decoder, simplified to
1 bit/clk symbol rate: '1' = toggle line level at UI boundary,
'0' = hold level (bi-phase-space). Decoder = toggle detect.
* Ordered sets (5-bit K-codes, sent MSB first):
K_SYNC1 = 5'b11000 (Sync-1), K_SYNC2 = 5'b10001 (Sync-2)
K_RST1  = 5'b00111 (RST-1),  K_RST2  = 5'b11001 (RST-2)
K_EOP   = 5'b01101 (EOP)
SOP       = {SYNC1,SYNC1,SYNC1,SYNC2}  (packed 20'hC6311, annotated as
28'h00C_6311 when zero-extended to 28 bits)
HardReset = {RST1,RST1,RST1,RST2}      (SOP'-class reset ordered set)
* Message frame: preamble(16 alt bits) + SOP + 16-bit header
{ext[15], numobj[14:12], msgid[11:9], powerrole[8], specrev[7:6],
datarole[5], msgtype[4:0]} + up to 2 x 32-bit data objects
+ CRC-32 (poly 0x04C11DB7 reflected -> 32'hEDB8_8320, init/xorout
all-ones, good-frame residue 32'hDEBB_20E3) + EOP.
* Policy engine (UFP): Source_Capabilities (fixed-supply PDOs
5V/1.5A + 9V/2A) -> GoodCRC -> Request (selects 9V PDO, obj pos 2)
-> GoodCRC -> Accept -> GoodCRC -> PS_RDY -> GoodCRC -> vbus_ok=1.
* Every valid received non-GoodCRC message is answered with GoodCRC
(echoing rx msgid). Bad CRC / framing / numobj>2 -> no GoodCRC + irq.
* HardReset ordered set detected any time receiver is hunting sync:
policy engine + TX abort back to initial state, vbus_ok cleared.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/USB_PD_top.sv` -- synthesizable RTL (top: `USB_PD_top`)
- `tb/USB_PD_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/USB_PD_yosys.ys` -- Yosys synthesis script
- `syn/USB_PD_dc.tcl` -- Synopsys Design Compiler script
- `syn/USB_PD.sdc` -- timing constraints
- `sim/filelist_USB_PD.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
