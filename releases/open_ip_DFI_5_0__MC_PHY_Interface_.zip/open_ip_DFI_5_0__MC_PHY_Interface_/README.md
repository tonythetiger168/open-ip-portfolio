# DFI_5_0__MC_PHY_Interface_ Open IP

DFI 5.0 (MC-PHY Interface) protocol IP -- PHY-side DFI model
Implementation scope (documented simplified subset of DFI 5.0):
- Single 1:1 frequency ratio slice: dfi_clk == clk (no 1:2/1:4 phase
alignment, documented simplification).
- Command channel sampled from the MC: dfi_address/dfi_bank/
dfi_ras_n/dfi_cas_n/dfi_we_n/dfi_cs_n/dfi_cke/dfi_odt.
DDR-style command decode {ras_n,cas_n,we_n} while cs_n=0:
ACT=3'b011  RD=3'b101  WR=3'b100  PRE=3'b010  REF=3'b001
NOP=3'b111  MRS=3'b000 (accepted, no mode-register side effects)
- Write data path: dfi_wrdata_en starts an internal PHY write delay
line; exactly t_phy_wrlat(=4) cycles later dfi_wrdata +
dfi_wrdata_mask (1 = byte masked off) are committed to the DRAM
array model.
- Read data path: dfi_rddata_en starts an internal PHY read delay
line; exactly t_phy_rdlat(=5) cycles later dfi_rddata_valid pulses
for one cycle with dfi_rddata (gated to 0 when not valid).
- Initialisation: dfi_init_start runs a 32-cycle init sequence, then
dfi_init_complete is held while dfi_init_start stays asserted
(DFI handshake); the initialised state persists after release.
Any non-NOP/DES command before initialisation is ignored + irq.
- Low power: dfi_lp_ctrl request is acknowledged with dfi_lp_ctrl_ack
after a 2-cycle handshake; commands while in LP are ignored + irq.
- Backing store: 8 banks x 32 rows x 32-bit DRAM array model.
- dfi_odt is sampled (termination) but has no data-path side effect.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/DFI_5_0__MC_PHY_Interface__top.sv` -- synthesizable RTL (top: `DFI_5_0__MC_PHY_Interface__top`)
- `tb/DFI_5_0__MC_PHY_Interface__tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/DFI_5_0__MC_PHY_Interface__yosys.ys` -- Yosys synthesis script
- `syn/DFI_5_0__MC_PHY_Interface__dc.tcl` -- Synopsys Design Compiler script
- `syn/DFI_5_0__MC_PHY_Interface_.sdc` -- timing constraints
- `sim/filelist_DFI_5_0__MC_PHY_Interface_.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
