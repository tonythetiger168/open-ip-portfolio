# Wishbone Open IP

Wishbone B4 pipelined slave -- real protocol IP design
Scope : WB B4 slave, pipelined mode (stall_o backpressure, in-order ack_o)
+ classic cycle compatibility (cti_i = 3'b000), SEL partial-write
merge, reserved region (adr >= 0x800) -> err_o, 256x32 regfile.
rty_o tied off (this slave never requests retry).
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/Wishbone_top.sv` -- synthesizable RTL (top: `Wishbone_top`)
- `tb/Wishbone_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/Wishbone_yosys.ys` -- Yosys synthesis script
- `syn/Wishbone_dc.tcl` -- Synopsys Design Compiler script
- `syn/Wishbone.sdc` -- timing constraints
- `sim/filelist_Wishbone.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
