# Bluetooth5 Open IP

Bluetooth 5 (BLE) link layer peripheral -- synthesizable baseband model
Implementation scope (simplified, NOT the full BLE LL specification):
- Air interface: 1 bit/clk, LSB-first per byte (BLE over-the-air order).
- Advertising channel 37: preamble 8'hAA + AccessAddress 32'h8E89BED6 +
PDU header {type[3:0],rfu[3:0],len[7:0]} + payload + CRC24
(serial LFSR, poly 24'h00065B, init 24'h555555).
- Data whitening: LFSR poly x^7+x^4+1 (out = l[6], l <<= l[6]^l[3]),
seed = channel_index | 1 (adv ch37 -> 7'h25); applied to everything
after the AccessAddress (header + payload + CRC).
- ADV_IND transmitted every ADV_INTV clks (payload = 16x8 host-writable
register file).  Valid SCAN_REQ -> SCAN_RSP (payload[i] = 8'h53+i).
- Valid CONNECT_REQ -> parse simplified LLData (15 bytes: AA[4],
CRCInit[3], interval[2], latency[2], timeout[2], hop[1], chmap[1]) ->
stored in registers, CONNECTION state on the new AA.  Hop increment is
stored but channel hopping is simplified to a fixed data channel
(chmap mod 37), noted.
- Data channel PDU: LL header {llid[1:0],sn,nesn,md,rfu[2:0]} + len[4:0]
+ payload (<=16B) + CRC24 (init = CRCInit).  NESN/SN toggle management;
every valid master PDU gets an empty-PDU response (ack); an empty PDU
keepalive is sent each connection interval without master traffic.
- Unknown advertising PDU type / bad CRC24 -> packet discarded + irq.
- llid 2'b00 reserved -> protocol error + irq.  len > 16 -> drop + irq.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/Bluetooth5_top.sv` -- synthesizable RTL (top: `Bluetooth5_top`)
- `tb/Bluetooth5_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/Bluetooth5_yosys.ys` -- Yosys synthesis script
- `syn/Bluetooth5_dc.tcl` -- Synopsys Design Compiler script
- `syn/Bluetooth5.sdc` -- timing constraints
- `sim/filelist_Bluetooth5.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
