# OCP_IP_Open_Core_Protocol Open IP

OCP-IP master -- real protocol IP design
Scope : OCP-IP master (initiator) side.  MCmd encoding : 0=IDLE, 1=WR,
2=RD, 5=WRNP (posted write, no response).  Bursts : INCR
(MBurstSeq=0), MBurstLength 1..8, address given once, write data
beats handshaken per-beat with SCmdAccept.  SCmdAccept backpressure
is obeyed (request held stable); 64 clk without SCmdAccept aborts
the transaction -> resp_err + sticky irq.  SResp : 1=DVA, 2=ERR
(ERR -> resp_err + sticky irq).  CPU-side transaction port:
req_valid/req_ready + req_rw/req_posted/req_addr/req_len/req_wdata
(write-burst data words are streamed after the descriptor while
req_ready is high) -> resp_valid/resp_rdata/resp_err.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/OCP_IP_Open_Core_Protocol_top.sv` -- synthesizable RTL (top: `OCP_IP_Open_Core_Protocol_top`)
- `tb/OCP_IP_Open_Core_Protocol_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/OCP_IP_Open_Core_Protocol_yosys.ys` -- Yosys synthesis script
- `syn/OCP_IP_Open_Core_Protocol_dc.tcl` -- Synopsys Design Compiler script
- `syn/OCP_IP_Open_Core_Protocol.sdc` -- timing constraints
- `sim/filelist_OCP_IP_Open_Core_Protocol.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
