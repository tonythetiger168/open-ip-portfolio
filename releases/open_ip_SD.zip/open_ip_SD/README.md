# SD Open IP

SD protocol Open IP -- SD memory card host: CMD0/CMD8/ACMD41/CMD2/CMD3/CMD7
init sequence, CMD24/CMD17 single-block read/write in 4-bit DAT mode,
CMD13 status poll, R1/R2/R3/R6/R7 response parsing, CRC7/CRC16 checking
Open IP design implementation v2.3 -- Apache-2.0
----------------------------------------------------------------------------
Documented simplifications (educational slice of the SD physical layer):
- Block length is 32 bytes (256 bits) instead of the SD-native 512 bytes.
- 4-bit bus mode from the start (bus-width switch via ACMD6 is skipped;
the host is born in 4-bit mode, documented deviation).
- sd_clk is generated from clk by an even divider (parameter SD_CLK_DIV);
all host logic runs in the clk domain and advances one bus bit per
sd_clk period (internal "tick" aligned with the sd_clk rising edge).
- CMD7's R1b busy on DAT0 is simplified to plain R1 (no busy wait).
- Response/data-start timeout is 64 sd_clk cycles.
- The host autonomously repeats demo rounds: CMD24 write of an internal
pattern block, CMD17 read-back compare, CMD13 status poll. Round n
uses block address n[1:0]. Status is observable via internal state
(TB hierarchical reference) and irq pulses.

## Package contents

- `rtl/SD_top.sv` -- synthesizable RTL (top: `SD_top`)
- `tb/SD_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/SD_yosys.ys` -- Yosys synthesis script
- `syn/SD_dc.tcl` -- Synopsys Design Compiler script
- `syn/SD.sdc` -- timing constraints
- `sim/filelist_SD.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
