# ARM_Q_Channel_Low_Power_Interface Open IP

ARM Q-Channel Low Power Interface -- device-side controller
Full qreqn/qacceptn/qdeny/qactive handshake FSM (Q_RUN, Q_REQUEST,
Q_STOPPED, Q_EXIT, Q_DENIED), qactive driven by internal activity
detection (dev_event counter), deny path, illegal-sequence detection -> irq
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/ARM_Q_Channel_Low_Power_Interface_top.sv` -- synthesizable RTL (top: `ARM_Q_Channel_Low_Power_Interface_top`)
- `tb/ARM_Q_Channel_Low_Power_Interface_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/ARM_Q_Channel_Low_Power_Interface_yosys.ys` -- Yosys synthesis script
- `syn/ARM_Q_Channel_Low_Power_Interface_dc.tcl` -- Synopsys Design Compiler script
- `syn/ARM_Q_Channel_Low_Power_Interface.sdc` -- timing constraints
- `sim/filelist_ARM_Q_Channel_Low_Power_Interface.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
