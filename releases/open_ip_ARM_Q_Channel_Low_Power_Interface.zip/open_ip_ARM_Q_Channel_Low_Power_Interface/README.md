# ARM_Q_Channel_Low_Power_Interface Open IP

ARM Q-Channel Low Power Interface -- device-side controller
Full qreqn/qacceptn/qdeny/qactive handshake FSM (Q_RUN, Q_REQUEST,
Q_STOPPED, Q_EXIT, Q_DENIED), qactive driven by internal activity
detection (dev_event counter), deny path, illegal-sequence detection -> irq
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/ARM_Q_Channel_Low_Power_Interface_top.sv` -- synthesizable RTL (top: `ARM_Q_Channel_Low_Power_Interface_top`)
- `tb/ARM_Q_Channel_Low_Power_Interface_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/ARM_Q_Channel_Low_Power_Interface_yosys.ys` -- Yosys synthesis script
- `syn/ARM_Q_Channel_Low_Power_Interface_dc.tcl` -- Synopsys Design Compiler script
- `syn/ARM_Q_Channel_Low_Power_Interface.sdc` -- timing constraints
- `sim/filelist_ARM_Q_Channel_Low_Power_Interface.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
