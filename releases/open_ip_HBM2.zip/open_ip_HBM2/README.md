# HBM2 Open IP

HBM2: 8-channel over the MEMCH_top multi-channel wrapper (PROTOCOL=19,
NCH=8, aligned with family sibling HBM_top). Educational slice of HBM2
timing (CL=14, tRCD=7, tRP=7); channel select = haddr[10:8], each channel
owns dq[ch*16 +: 16] (8 x 16 = dq[127:0]). Ports identical to family
sibling DDR4_top; gem5 trace port unchanged. MEMCORE_top is not modified;
PROTOCOL=19 is a family tag only (MEMCORE timing is fully parameterized
via CL/TRCD/TRP).
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/HBM2_top.sv (+ MEMCORE_top.sv, MEMCH_top.sv)` -- synthesizable RTL (top: `HBM2_top`)
- `tb/HBM2_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/HBM2_yosys.ys` -- Yosys synthesis script
- `syn/HBM2_dc.tcl` -- Synopsys Design Compiler script
- `syn/HBM2.sdc` -- timing constraints
- `sim/filelist_HBM2.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
