# SAS_4__Serial_Attached_SCSI_ Open IP

SAS-4 (Serial Attached SCSI, 24G) -- 128b/150b-style block-coded link layer
initiator IP.  Distinct from SAS_top (v1.7 NRZ + dword link): this core
implements a 128b/150b-style block code and a self-synchronous scrambler.
Implementation scope (simplified, NOT the full SPL specification):
- Block code: 2-bit sync header (2'b01 = data block, 2'b10 = control
block) + 128-bit payload block = 130 bits/block, MSB first, 1 bit/clk.
Sync header bits are never scrambled (64b/66b-style); payloads are.
- Scrambler: self-synchronous.  SAS-4 specifies x^58+x^39+1; simplified
here to x^16+x^5+1 (noted): obit = dbit ^ s[15] ^ s[4], s <<= obit.
The same LFSR stream runs continuously across all block payloads
(idle blocks included), so the line never carries plaintext.
- Frame format: SOF control block + header data block {type,dst,src,len}
(one 32-bit dword per field, value in low 8 bits) + payload data
block(s) (len <= 8 dwords, zero padded to 4-dword blocks) + CRC32 data
block (dword0 = CRC, poly 0x04C11DB7 reflected, init/xorout all-ones,
covering header + padded payload blocks) + EOF control block.
Idle control blocks are sent between frames.
- OOB: SNW-style burst/idle handshake (106 clk burst, 318 clk idle,
>=64 clk run detect) -> PHY READY (link_up).
- Loss of sync: 8 consecutive invalid sync headers (2'b00/2'b11) while
locked -> loss_sync: irq pulse, link_down and full re-OOB.
- Functional unit: 16x32 register file.  type 8'h01 = write (payload[0]),
8'h02 = read request, 8'h83 = read response (payload[0] = reg value).
A built-in initiator sequencer loops write + read-verify transactions
over the loopback link.
- irq: 1-clk pulse on CRC error, protocol violation, link timeout or
loss of sync.
NOTE: clk is used as the line bit clock (1 bit/clk).  rx_n is the
inverted companion of rx_p and is unused by this single-ended model.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/SAS_4__Serial_Attached_SCSI__top.sv` -- synthesizable RTL (top: `SAS_4__Serial_Attached_SCSI__top`)
- `tb/SAS_4__Serial_Attached_SCSI__tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/SAS_4__Serial_Attached_SCSI__yosys.ys` -- Yosys synthesis script
- `syn/SAS_4__Serial_Attached_SCSI__dc.tcl` -- Synopsys Design Compiler script
- `syn/SAS_4__Serial_Attached_SCSI_.sdc` -- timing constraints
- `sim/filelist_SAS_4__Serial_Attached_SCSI_.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
