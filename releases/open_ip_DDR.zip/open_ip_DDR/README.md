# DDR Open IP

DDR: single-channel over the MEMCH_top multi-channel wrapper (PROTOCOL=17,
NCH=1). Educational slice of DDR3-generation SDRAM timing
(CL=5, tRCD=5, tRP=5). Ports identical to family sibling DDR4_top;
gem5 trace port unchanged. MEMCORE_top is not modified; PROTOCOL=17 is a
family tag only (MEMCORE timing is fully parameterized via CL/TRCD/TRP).
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/DDR_top.sv (+ MEMCORE_top.sv, MEMCH_top.sv)` -- synthesizable RTL (top: `DDR_top`)
- `tb/DDR_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/DDR_yosys.ys` -- Yosys synthesis script
- `syn/DDR_dc.tcl` -- Synopsys Design Compiler script
- `syn/DDR.sdc` -- timing constraints
- `sim/filelist_DDR.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
