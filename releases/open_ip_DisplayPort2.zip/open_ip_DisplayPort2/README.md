# DisplayPort2 Open IP

DisplayPort2 protocol Open IP -- DisplayPort source (TX) educational slice:
main link 1 lane with ANSI 8b/10b encoding (full D-code table + K28.5 /
K23.7 / K27.7 / K29.7 / K30.7 control codes, running-disparity tracking),
link-training FSM (D10.2 clock-recovery pattern -> TPS1 = K28.5 + D10.2
sequence with simplified TRAINING_PATTERN_SET semantics -> trained),
video streaming (BS/BE blanking marks + pixel data + SS/SE framed MSA
packet: VB-ID / Mvid[23:0] simplified to 4 dwords), AUX channel with
Manchester-II coding (1 bit = 2 clk chips), SYNC 16'h0000 preamble +
start bit, commands {native AUX write/read, I2C-over-AUX write/read},
addr[20] + len[8] + data + simplified stop (CRC replaced by stop chips),
DPCD register window access (16 x 8: link rate / lane count / training
pattern / lane status), I2C-over-AUX read of the first 8 EDID bytes.
Open IP design implementation v2.3 -- Apache-2.0
----------------------------------------------------------------------------
Documented simplifications (educational slice of the DP physical layer):
- 1 lane, serialisation 1 bit/clk; the 10-bit 8b/10b code is transmitted
'a' first (DP-native bit order), 10 clk per symbol, gap-free.
- AUX Manchester-II at 2 clk chips per bit (IEEE 802.3 convention:
logical 1 = chips (1,0), logical 0 = chips (0,1)). Idle line = 1.
SYNC = 16 zero bits + one start bit (1). STOP = chips (1,1).
AUX CRC nibble is replaced by the STOP chip pair (documented).
- DPCD window model: addr0 = LINK_RATE(0x14), addr1 = LANE_COUNT(1),
addr2 = TRAINING_PATTERN_SET (0x21=CR, 0x22=TPS1, 0x00=off),
addr3 = LANE0_STATUS (bit0 CR_DONE, bit1 EQ_DONE) -- lives in the sink.
- I2C-over-AUX: addr = {4'h0, i2c_dev[7:0], offset[7:0]}; write with
len=0 sets the EDID offset; read returns len bytes from EDID ROM.
- Link training: send >=32 CR symbols then poll LANE0_STATUS; up to 3
retries per phase; AUX timeout / NACK / Manchester violation retried
3 times, then train_fail + irq (sticky until reset).
- Video line (40 symbols, documented simplification):
BS(K27.7), 16 pixel D-symbols (pixel[i] = frame_cnt+i), BE(K28.5),
SS(K29.7), 16 MSA bytes (4 dwords LSB-first: {8'h00,8'h00,fc,8'h01},
32'h0012_3456 (Mvid), 32'h140 (Htotal), 32'h0F0 (Vtotal)), SE(K30.7),
FS(K23.7) + 3 x D00.0 fill. K23.7 fill is sent whenever the link is
up but no video/training pattern is active.

## Package contents

- `rtl/DisplayPort2_top.sv` -- synthesizable RTL (top: `DisplayPort2_top`)
- `tb/DisplayPort2_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/DisplayPort2_yosys.ys` -- Yosys synthesis script
- `syn/DisplayPort2_dc.tcl` -- Synopsys Design Compiler script
- `syn/DisplayPort2.sdc` -- timing constraints
- `sim/filelist_DisplayPort2.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
