# OCP Open IP

OCP protocol -- OCP-IP 3.0 slave (MCmd/MAddr/MData -> SCmdAccept/SData/SResp)
Scope: basic data-handshake subset of OCP-IP:
- MCmd: IDLE=0 / WR=1 / RD=2 / WRNP=5 (posted write, no response)
- configurable command-accept latency (ACCEPT_DLY = 0 or 1)
- fixed 2-cycle DVA response latency for WR/RD, SData valid with DVA
- MByteEn partial-write merge, MThreadID echoed on SThreadID
- 256x32 register file (1 KiB, word aligned); accesses outside
0x000..0x3FC or misaligned -> SResp=ERR + irq pulse
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/OCP_top.sv` -- synthesizable RTL (top: `OCP_top`)
- `tb/OCP_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/OCP_yosys.ys` -- Yosys synthesis script
- `syn/OCP_dc.tcl` -- Synopsys Design Compiler script
- `syn/OCP.sdc` -- timing constraints
- `sim/filelist_OCP.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
