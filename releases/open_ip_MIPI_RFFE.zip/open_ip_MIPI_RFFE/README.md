# MIPI_RFFE Open IP

MIPI RFFE protocol IP -- RFFE slave controller
Implementation scope (documented simplified subset of MIPI RFFE v2.x):
- SSC detection: SDATA held high >= 20 clk while SCLK low (longer than any
in-frame low-phase, so data traffic can never alias to an SSC)
- Command frame, 13 bits: SA[3:0] | C[2:0] | A[4:0] | P (even parity)
C=3'b010 : register write      -> data frame D[7:0]|P
C=3'b011 : register read       -> BP cycle, slave drives D[7:0]|P
C=3'b110 : extended reg write  -> A[3:0]=BC(1..8), address frame
A[7:0]|P then BC data frames
- 16x8 register file, auto-increment on extended writes
- parity error / unknown USID / illegal command -> no response + irq
(sticky until the next SSC)
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/MIPI_RFFE_top.sv` -- synthesizable RTL (top: `MIPI_RFFE_top`)
- `tb/MIPI_RFFE_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/MIPI_RFFE_yosys.ys` -- Yosys synthesis script
- `syn/MIPI_RFFE_dc.tcl` -- Synopsys Design Compiler script
- `syn/MIPI_RFFE.sdc` -- timing constraints
- `sim/filelist_MIPI_RFFE.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
