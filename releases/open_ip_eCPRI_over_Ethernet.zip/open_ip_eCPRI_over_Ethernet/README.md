# eCPRI_over_Ethernet Open IP

eCPRI over Ethernet -- eCPRI message layer slice (node side)
- Ethernet frame parse/generate: DMAC + SMAC + Ethertype 0xAEFE +
payload + FCS (CRC-32/ISO-HDLC reflected, init/xorout 0xFFFFFFFF,
FCS sent LSB-byte first; rx residue check == 0xDEBB20E3).
Preamble/SFD/IFG are handled by the external MAC (byte stream i/f).
- eCPRI common header {rev[4],rsvd[3],c[1], msgtype[8], payload_size[16]}
- msgtype 0: IQ data -- pc_id[16] + seq_id[16] + IQ bytes (<=32B, must be
a multiple of 4) packed big-endian into a 32x32 IQ buffer (cpu pop);
seq_id gap tracking per link
- msgtype 4: generic memory transfer -- remote_addr[32] + rw[8]
(1=write + data[32], 0=read) against a 64x32 memory; read triggers a
response frame (rw=2) with the memory content
- msgtype 5: remote reset request -- reset_op[16] drives the reset_op
output + response frame echoing reset_op
- msgtype 6: event indication -- event_id[8] + ack_req[8]; ack_req!=0
triggers an event ACK frame; cpu fault-injection register emits an
event indication frame
- FCS-bad frames dropped + irq; unknown msgtype / malformed payload /
concatenated messages (c=1) dropped + irq
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/eCPRI_over_Ethernet_top.sv` -- synthesizable RTL (top: `eCPRI_over_Ethernet_top`)
- `tb/eCPRI_over_Ethernet_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/eCPRI_over_Ethernet_yosys.ys` -- Yosys synthesis script
- `syn/eCPRI_over_Ethernet_dc.tcl` -- Synopsys Design Compiler script
- `syn/eCPRI_over_Ethernet.sdc` -- timing constraints
- `sim/filelist_eCPRI_over_Ethernet.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
