# SAS Open IP

SAS protocol Open IP -- SAS initiator (OOB + SSP frame link layer)
-- Apache-2.0
Open IP design implementation v2.4
Implementation scope:
- OOB FSM: COMRESET-style burst/idle pattern (106 symbol burst + 318 symbol
idle), COMINIT exchange detection, then PHY READY.
- Link layer: ALIGN idle primitive (32'h7B4A4ABC) inserted between frames,
1 bit/clk serialisation, MSB-first per 32-bit dword, tx_n = ~tx_p.
- SSP frame: SOF(32'hA5A50001) + HDR{len[31:24],type[23:16],dst[15:8],
src[7:0]} + PAYLOAD(len x 32-bit, len<=16) + CRC32 + EOF(32'hA5A50002).
- CRC32: poly 32'h04C11DB7 (reflected form 32'hEDB88320), init all-ones,
input/output reflected, final XOR all-ones (Ethernet FCS style),
processed one 32-bit dword per step over HDR + PAYLOAD.
- Functional unit: 16x32-bit register file. type 8'h01 = write,
8'h02 = read request, 8'h83 = read response (payload[0] = reg value).
- Built-in initiator sequencer issues write / read-verify transactions so
the IP exercises itself over the loopback link.
- irq: 1-clk pulse on CRC error or protocol violation (oversize len,
bad EOF, unknown frame type, bad register address, link timeout).
NOTE: refclk is kept for interface compatibility; this simplified model
uses clk as the line bit clock (1 bit/clk) and does not use refclk.
rx_n is the inverted companion of rx_p and is not used by the simplified
receiver (single-ended sampling on rx_p).

## Package contents

- `rtl/SAS_top.sv (+ SATA_top.sv)` -- synthesizable RTL (top: `SAS_top`)
- `tb/SAS_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `tb/SAS_bitclks_tb.sv` -- directed functional TB at BIT_CLKS=4 (make sim_bitclks)
- `syn/SAS_yosys.ys` -- Yosys synthesis script
- `syn/SAS_dc.tcl` -- Synopsys Design Compiler script
- `syn/SAS.sdc` -- timing constraints
- `sim/filelist_SAS.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
