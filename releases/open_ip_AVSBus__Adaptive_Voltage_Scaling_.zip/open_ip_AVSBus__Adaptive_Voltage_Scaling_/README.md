# AVSBus__Adaptive_Voltage_Scaling_ Open IP

AVSBus (Adaptive Voltage Scaling, PMBus-style) -- synthesizable slave
Scope: serial sclk/sdat (open-drain) frame interface:
START + addr[6:0] + cmd[7:0] + data[15:0] + CRC4 + ACK/NACK slot,
GET reads back {4'h0, vdac} + CRC4; set/get voltage commands with an
internal 12-bit DAC code register and a voltage ramp FSM (10 mV/clk,
1 code = 1 mV). NACK on illegal address / bad CRC / unknown command.
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/AVSBus__Adaptive_Voltage_Scaling__top.sv` -- synthesizable RTL (top: `AVSBus__Adaptive_Voltage_Scaling__top`)
- `tb/AVSBus__Adaptive_Voltage_Scaling__tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/AVSBus__Adaptive_Voltage_Scaling__yosys.ys` -- Yosys synthesis script
- `syn/AVSBus__Adaptive_Voltage_Scaling__dc.tcl` -- Synopsys Design Compiler script
- `syn/AVSBus__Adaptive_Voltage_Scaling_.sdc` -- timing constraints
- `sim/filelist_AVSBus__Adaptive_Voltage_Scaling_.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
