# MIPI_I3C Open IP

MIPI I3C protocol IP -- I3C slave controller
Implementation scope:
- Legacy I2C write/read on a 7-bit static address (16x8 register file)
- ENTDAA dynamic address assignment (broadcast CCC 0x07): slave returns
48-bit PID + BCR + DCR, then captures the 7-bit dynamic address
- Direct CCC GETPID (0x8C): subsequent addressed read returns 6 PID bytes
- IBI (in-band interrupt): slave pulls SDA while bus idle, arbitrates its
dynamic address, then pushes one IBI data byte
- Open-drain vs push-pull phase switching (address/arbitration phases are
open-drain, data transmit phases are push-pull -- simplified, the pad is
a shared clk-domain model so both are driven from the same enable logic)
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/MIPI_I3C_top.sv` -- synthesizable RTL (top: `MIPI_I3C_top`)
- `tb/MIPI_I3C_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/MIPI_I3C_yosys.ys` -- Yosys synthesis script
- `syn/MIPI_I3C_dc.tcl` -- Synopsys Design Compiler script
- `syn/MIPI_I3C.sdc` -- timing constraints
- `sim/filelist_MIPI_I3C.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
