# UFS Open IP

UFS protocol Open IP -- UFS host: simplified UniPro frame link + UPIU
command transactions (TEST UNIT READY / READ10 / WRITE10 on a serial lane)
Open IP design implementation v2.4
-- Apache-2.0
Simplifications (per SPEC.md section 2.4):
* refclk is kept for interface compatibility only; the lane symbol clock is
derived from clk (1 bit per clk, MSB-first within each 32-bit dword).
* Frame : SOF(32'h5546_5301) HDR PAYLOAD(len <= 8 dwords) CRC32 EOF(32'h5546_5302)
HDR   : {type[7:0], task_tag[7:0], lun[7:0], len[7:0]}
CRC32 : poly 32'h04C11DB7 (reflected shift form 32'hEDB8_8320), init
all-ones, final XOR all-ones; computed over the on-the-wire bit
stream of HDR+PAYLOAD and transmitted as one dword MSB-first.
* COMMAND UPIU (type 8'h01): payload[0..3] = 16-byte CDB
dword0 = {opcode[7:0], lba[23:0]}, dword1 = {xfer_dwords[7:0], 24'h0}
WRITE10 data is carried inline in payload[4..7] (count = len-4 dwords)
* RESPONSE UPIU (type 8'h81): payload[0] = {sense[15:0], status[15:0]}
READ10 data follows in a DATA UPIU (type 8'h02)
* LUN0 medium: internal 256 x 32-bit storage array.
* irq pulses one clk on: CRC mismatch, unknown opcode, len > 8, bad EOF,
malformed CDB or out-of-range LBA/transfer length.

## Package contents

- `rtl/UFS_top.sv (+ SATA_top.sv)` -- synthesizable RTL (top: `UFS_top`)
- `tb/UFS_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/UFS_yosys.ys` -- Yosys synthesis script
- `syn/UFS_dc.tcl` -- Synopsys Design Compiler script
- `syn/UFS.sdc` -- timing constraints
- `sim/filelist_UFS.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
