# USB_Type_C_Port_Controller Open IP

USB Type-C Port Controller (TCPC) -- DRP port controller
Implementation scope:
* cc1/cc2 3-level analog-line inputs, encoded as 2-bit enum:
CC_OPEN = 2'b00 (nothing connected / line open)
CC_RD   = 2'b01 (sink pull-down Rd present)
CC_RA   = 2'b10 (powered-cable / audio accessory Ra present)
2'b11   = abnormal level (fault injection, raises irq)
* Attach-detect FSM: UNATTACHED -> ATTACHWAIT (100 clk debounce)
-> ATTACHED; orientation resolved from which CC pin saw Rd
(cc1 -> orientation=0, cc2 -> orientation=1). Ra-only or Rd on
both pins is not a sink attach and is ignored.
* Detach detect: active CC pin back to OPEN for 10 consecutive clks.
* vbus_en: asserted in ATTACHED when configured role is source (DFP);
stays low for sink role.
* 8 x 8-bit register port (I2C-style register file over a simplified
parallel command interface: reg_addr/reg_wdata/reg_rdata/reg_rd/reg_wr):
0 CC_STATUS  RO  {attached, orientation, fsm[1:0], cc2[1:0], cc1[1:0]}
1 ROLE_CTRL  RW  bit0: 1 = source/DFP (default), 0 = sink/UFP
2 FAULT_STAT RW1C bit0: abnormal CC level seen (sticky)
3 INT_STAT   RW1C bit0 attach, bit1 detach, bit2 fault (sticky)
4 DEBOUNCE   RO  attach debounce value (8'd100)
5 ORIENT     RO  bit0 = orientation
6 VBUS_STAT  RO  bit0 = vbus_en
7 DEVICE_ID  RO  8'hC7
* irq: asserted while an abnormal CC level is present or while any
sticky INT_STAT bit is set (cleared via RW1C write).
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/USB_Type_C_Port_Controller_top.sv` -- synthesizable RTL (top: `USB_Type_C_Port_Controller_top`)
- `tb/USB_Type_C_Port_Controller_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/USB_Type_C_Port_Controller_yosys.ys` -- Yosys synthesis script
- `syn/USB_Type_C_Port_Controller_dc.tcl` -- Synopsys Design Compiler script
- `syn/USB_Type_C_Port_Controller.sdc` -- timing constraints
- `sim/filelist_USB_Type_C_Port_Controller.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
