# MIPI_DPI__Display_Pixel_Interface_ Open IP

MIPI DPI (Display Pixel Interface) transmitter -- parallel RGB video timing
Implementation scope:
* Programmable timing generator: horizontal hfp/hsw/hbp/hact and vertical
vfp/vsw/vbp/vact in 8 x 16-bit registers (reg 0..7); frame FSM walks
front porch -> sync -> back porch -> active in both dimensions,
1 pixel per clk (pclk forwarded 1:1 from clk, all video outputs change
on the pclk rising edge)
* Outputs: pclk, hsync, vsync (active high), de, rgb[23:0]; pixel source
is the pixel[23:0] input, sampled in the active region
* Control register (reg 8): bit0 enable, bit1 shutdown (outputs forced
low, counters held), bit2 color_mode (18-bit color: 2 LSBs of each
channel masked)
* Enabling with any timing register == 0 is rejected and raises irq
* frame_cnt output increments at each vertical wrap; reg readback port
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/MIPI_DPI__Display_Pixel_Interface__top.sv` -- synthesizable RTL (top: `MIPI_DPI__Display_Pixel_Interface__top`)
- `tb/MIPI_DPI__Display_Pixel_Interface__tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/MIPI_DPI__Display_Pixel_Interface__yosys.ys` -- Yosys synthesis script
- `syn/MIPI_DPI__Display_Pixel_Interface__dc.tcl` -- Synopsys Design Compiler script
- `syn/MIPI_DPI__Display_Pixel_Interface_.sdc` -- timing constraints
- `sim/filelist_MIPI_DPI__Display_Pixel_Interface_.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
