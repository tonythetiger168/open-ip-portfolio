# DSI Open IP

MIPI DSI host transmitter (packet layer, command + video mode, BTA)
Implementation scope:
* Serial HS output model: 1 bit/clk on tx_bit while tx_valid is high,
LSB-first per byte; SoT sync byte 8'hB8 per packet (lane/LP states
abstracted: tx_oe marks host bus ownership, idle level = 1)
* Packet layer identical to CSI-2: header DI+WC/data[15:0]+ECC
(Hamming(30,24) subset, P7=P6=0, single-error correction on receive),
long packets append CRC-16/CCITT (poly 0x1021, init 0xFFFF)
* Command ops (cmd_op):
0 OP_SPKT   raw short packet        (DT=cmd_dt, data=cmd_len)
1 OP_DCS_S0 DCS short write 0 param (DT=0x05, e.g. set_display_on 0x29)
2 OP_DCS_S1 DCS short write 1 param (DT=0x15, e.g. set_pixel_format 0x3A)
3 OP_DCS_L  DCS long write          (DT=0x39, WC=cmd_len, e.g.
column/page address 0x2A/0x2B)
4 OP_VLINE  video-mode line: HSS(0x21)/HSE(0x31)/HBP blanking
(0x19, WC=cmd_len2)/HACT RGB888 (0x3E, WC=cmd_len)
5 OP_DCS_RD DCS read (DT=0x06) + bus turn-around
* BTA: after the read-request packet the host sends the BTA trigger byte
(8'h84, escape-command abstraction), releases the lane (tx_oe=0) and
receives a peripheral short-packet response with ECC checking
(single-error corrected); timeout or uncorrectable ECC raises irq
* 32-byte payload RAM written via pl_we/pl_addr before long commands
(long-packet WC must be <= PLEN)
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/DSI_top.sv` -- synthesizable RTL (top: `DSI_top`)
- `tb/DSI_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/DSI_yosys.ys` -- Yosys synthesis script
- `syn/DSI_dc.tcl` -- Synopsys Design Compiler script
- `syn/DSI.sdc` -- timing constraints
- `sim/filelist_DSI.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
