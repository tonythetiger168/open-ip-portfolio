# CSE Open IP

CSE -- Crypto & Security Engine: real AES-128 (FIPS-197) ECB core.
* Full SubBytes/ShiftRows/MixColumns/AddRoundKey + on-the-fly key
expansion; iterative datapath, 1 round/clk, 10 rounds
* Parallel command port: 128-bit key written as 4x32 words
(key_we/key_widx/key), start/din[127:0]/enc_dec -> busy/done/dout
* Command queue depth 1: a new start or key write while busy is a
protocol violation -> irq pulse (command ignored)
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/CSE_top.sv` -- synthesizable RTL (top: `CSE_top`)
- `tb/CSE_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/CSE_yosys.ys` -- Yosys synthesis script
- `syn/CSE_dc.tcl` -- Synopsys Design Compiler script
- `syn/CSE.sdc` -- timing constraints
- `sim/filelist_CSE.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
