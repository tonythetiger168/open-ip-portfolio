# MIPI_SPMI Open IP

MIPI SPMI protocol IP -- SPMI slave controller
Implementation scope (documented simplified subset of MIPI SPMI v2.x):
- SSC detection: SDATA held high >= 20 clk while SCLK low (longer than
any in-frame low-phase, so data traffic can never alias to an SSC)
- Command frame, 12 bits: SA[3:0] | C[3:0] | A[3:0]
C=4'h0 : register 0 write  (SPMI 0x00 class) -> data frame D[7:0]|P
C=4'h2 : register 0 read   (SPMI 0x20 class) -> slave drives D[7:0]|P
C=4'h3 : extended reg write(SPMI 0x30 class) -> A=BC(1..8), address
frame A[7:0]|P then BC data frames
C=4'h8 : extended reg read (SPMI 0x38 class) -> A=BC(1..8), address
frame then slave drives BC data frames
- A-bit arbitration on the 13th clock: master drives the A-bit; A=1 keeps
the bus (writes require A=1), A=0 grants the bus to the slave (reads).
A read requested with A=1 is yielded to the master (slave stays silent,
priority arbitration simplified to monitoring the A-bit).
- NACK (no-response) on illegal command / illegal BC / unknown SA + irq
- bus park: one SCLK cycle with SDATA driven low ends every transaction;
the slave recognises it and returns to idle
- 16x8 register file, auto-increment on extended accesses
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/MIPI_SPMI_top.sv` -- synthesizable RTL (top: `MIPI_SPMI_top`)
- `tb/MIPI_SPMI_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/MIPI_SPMI_yosys.ys` -- Yosys synthesis script
- `syn/MIPI_SPMI_dc.tcl` -- Synopsys Design Compiler script
- `syn/MIPI_SPMI.sdc` -- timing constraints
- `sim/filelist_MIPI_SPMI.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
