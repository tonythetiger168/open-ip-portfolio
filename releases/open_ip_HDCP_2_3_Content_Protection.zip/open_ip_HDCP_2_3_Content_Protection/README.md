# HDCP_2_3_Content_Protection Open IP

HDCP 2.3 Content Protection Open IP -- HDCP 2.3 transmitter (educational slice)
Full authentication FSM: AKE_Init -> rtx/rxcaps exchange -> master key km
-> session key derivation -> pairing -> locality check (20 clk challenge)
-> session key exchange -> repeater-ready (if peer REPEATER bit) ->
authenticated streaming cipher on the pixel interface.
Open IP design implementation v2.3 -- Apache-2.0
----------------------------------------------------------------------------
*** 非真實 AES，教育替代 / NOT real AES -- educational substitute crypto ***
Documented simplifications (this is NOT cryptographically secure):
- Session key derivation is a 128-bit XorShift mixing function of km and
rtx (mix128), NOT the real HDCP AES-128/HMAC-SHA256 based KDF.
- Pairing "encrypted master key" E_km is km XOR a replicated receiver
public-key-hash placeholder, NOT RSA-OAEP.
- Locality check response is L XOR ks[63:0], NOT HMAC; the 20-clock
response window models the real locality timer.
- Content encryption is a 32-bit XorShift LFSR keystream XORed with the
pixel stream, NOT AES-CTR. Both endpoints share the keystream so the
stream is recoverable by the peer (educational loopback).
- The DDC/I2C transport of real HDCP is replaced by parallel
valid/ready message channels (txm_*/rxm_*).
- Certificate exchange is collapsed to a single AKE_Send_Cert message
carrying rxcaps (REPEATER bit) and a 32-bit rx pubkey-hash placeholder.

## Package contents

- `rtl/HDCP_2_3_Content_Protection_top.sv` -- synthesizable RTL (top: `HDCP_2_3_Content_Protection_top`)
- `tb/HDCP_2_3_Content_Protection_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/HDCP_2_3_Content_Protection_yosys.ys` -- Yosys synthesis script
- `syn/HDCP_2_3_Content_Protection_dc.tcl` -- Synopsys Design Compiler script
- `syn/HDCP_2_3_Content_Protection.sdc` -- timing constraints
- `sim/filelist_HDCP_2_3_Content_Protection.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
