# LPDDR Open IP

LPDDR: single-channel over the MEMCH_top multi-channel wrapper (PROTOCOL=18,
NCH=1). Educational slice of LPDDR1/2-generation SDRAM timing
(CL=3, tRCD=3, tRP=3). Ports identical to family sibling DDR4_top
(addr/ras_n/cas_n/we_n command bus, not the LPDDR4 CA bus); gem5 trace
port unchanged. MEMCORE_top is not modified; PROTOCOL=18 is a family tag
only (MEMCORE timing is fully parameterized via CL/TRCD/TRP).
Open IP design implementation v2.5.1 -- Apache-2.0

## Package contents

- `rtl/LPDDR_top.sv (+ MEMCORE_top.sv, MEMCH_top.sv)` -- synthesizable RTL (top: `LPDDR_top`)
- `tb/LPDDR_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/LPDDR_yosys.ys` -- Yosys synthesis script
- `syn/LPDDR_dc.tcl` -- Synopsys Design Compiler script
- `syn/LPDDR.sdc` -- timing constraints
- `sim/filelist_LPDDR.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.5.1: constrained-random testbenches (portable `ifdef VERILATOR`); RTL fixes: echo-copy/MEMCH OOB bounds, RFFE/HSI/I3C/SPMI/QSPI/1-Wire serial bugs, USB2.0 run_cnt, USB3 give-up, CXL-family STP/LEN=8, WTB tok_irq, NVMe TX replay bound. Verified: iverilog sim PASS.
