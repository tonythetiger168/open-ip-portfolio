# eMMC Open IP

eMMC protocol Open IP -- eMMC host: CMD0/CMD1/CMD2/CMD3 init sequence,
CMD24/CMD17 single-block read/write in 1-bit DAT mode, CRC7/CRC16 checking
-- Apache-2.0
Open IP design implementation v2.4
----------------------------------------------------------------------------
Documented simplifications (SPEC section 2.5):
- Block length is 32 bytes (256 bits) instead of the eMMC-native 512 bytes.
- 1-bit bus mode only: host drives/samples dat[0]; dat[7:1] stay high-Z.
- All host logic runs in the emmc_clk (bus clock) domain; clk is the
system clock and is reserved/unused internally (single-clock design).
- rst_n and emmc_rst_n are combined into one asynchronous reset (srst_n).
- Response wait timeout is 64 emmc_clk cycles (SPEC: N <= 64).
- The host autonomously repeats demo rounds: CMD24 write of an internal
pattern block, then CMD17 read of the same block with read-back compare.
Round n uses block address n[1:0]. Status is observable via internal
state (TB hierarchical reference) and irq pulses.

## Package contents

- `rtl/eMMC_top.sv` -- synthesizable RTL (top: `eMMC_top`)
- `tb/eMMC_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/eMMC_yosys.ys` -- Yosys synthesis script
- `syn/eMMC_dc.tcl` -- Synopsys Design Compiler script
- `syn/eMMC.sdc` -- timing constraints
- `sim/filelist_eMMC.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
