# CSI_2 Open IP

MIPI CSI-2 receiver (camera side link, packet layer)
Implementation scope:
* Serial HS input model: 1 bit/clk on rx_bit while rx_valid is high,
LSB-first per byte (D-PHY/lane deskew abstracted, see note in body)
* SoT hunt: 8'hB8 sync byte, then packet header DI/VC + WC/data[15:0]
+ ECC byte (Hamming(30,24) subset, P7=P6=0):
- syndrome == 0            -> clean header
- syndrome in D0..D23 table-> single error corrected in place
- syndrome == 6'h01..6'h20 -> error inside ECC byte itself, data ok
- otherwise                -> uncorrectable, packet dropped + irq
* Short packets (DT 6'h00..6'h0F): FS=0x00 / FE=0x01 frame control,
LS=0x02 / LE=0x03 line control, 16-bit data field captured
* Long packets (DT >= 6'h10, e.g. RAW8=0x2B): WC[15:0] payload bytes
into a 1-line x 512-byte pixel buffer, then CRC-16/CCITT
(poly 0x1021, init 0xFFFF, LSB-first on the wire) checked; bad CRC
drops the line and raises irq
* Status: frame_cnt / line_cnt, last DT/VC/WC, error flags, line
buffer read-out port (lb_addr/lb_rdata + lb_len)
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/CSI_2_top.sv` -- synthesizable RTL (top: `CSI_2_top`)
- `tb/CSI_2_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/CSI_2_yosys.ys` -- Yosys synthesis script
- `syn/CSI_2_dc.tcl` -- Synopsys Design Compiler script
- `syn/CSI_2.sdc` -- timing constraints
- `sim/filelist_CSI_2.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
