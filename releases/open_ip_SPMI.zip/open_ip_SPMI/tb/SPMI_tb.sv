// SPDX-License-Identifier: Apache-2.0
// Self-checking testbench: TB acts as SPMI master -- SystemVerilog
`timescale 1ns/1ps
module SPMI_tb;
  logic clk = 0, rst_n = 0;
  tri1  sdata;
  logic sclk = 0;
  logic m_low = 0;
  logic [7:0] rx_byte, rx_addr;
  logic [7:0] tx_byte = 8'hC2;   // v2.5.1: LSB=0 locks the bus-wedge fix
  logic rx_valid, busy;
  logic rx_seen = 0;
  int errors = 0;

  SPMI_top #(.SPMI_ADDR(4'h5)) dut (
    .clk(clk), .rst_n(rst_n), .sdata(sdata), .sclk(sclk),
    .rx_byte(rx_byte), .rx_addr(rx_addr), .rx_valid(rx_valid),
    .tx_byte(tx_byte), .busy(busy), .irq());

  always #5 clk = ~clk;
  assign sdata = m_low ? 1'b0 : 1'bz;
  always @(posedge clk) if (rx_valid) rx_seen <= 1'b1;

  task automatic ssc;
    begin m_low = 0; sclk = 1; #300;       // SCLK high first
          m_low = 1; #300;                 // SDATA falls while SCLK high
          sclk = 0; #300;
          m_low = 0; #300; end
  endtask
  task automatic sbit(input logic b);
    begin m_low = ~b; #300; sclk = 1; #600; sclk = 0; #300; end
  endtask
  task automatic srelease(output logic b);
    begin m_low = 0; #300; sclk = 1; #300; b = sdata; #300; sclk = 0; #300; end
  endtask

  task automatic spmi_write(input logic [3:0] sa, input logic [7:0] ad,
                            input logic [7:0] data);
    begin
      ssc;
      for (int i = 3; i >= 0; i--) sbit(sa[i]);
      sbit(0); sbit(0); sbit(0); sbit(0);      // CMD = write
      for (int i = 7; i >= 0; i--) sbit(ad[i]);
      for (int i = 7; i >= 0; i--) sbit(data[i]);
      srelease_bit_ack();
      #600;
    end
  endtask

  task automatic spmi_read(input logic [3:0] sa, input logic [7:0] ad,
                           output logic [7:0] data);
    logic b;
    begin
      ssc;
      for (int i = 3; i >= 0; i--) sbit(sa[i]);
      sbit(0); sbit(0); sbit(0); sbit(1);      // CMD = read
      for (int i = 7; i >= 0; i--) sbit(ad[i]);
      for (int i = 7; i >= 0; i--) begin        // slave drives data immediately
        srelease(b);
        data[i] = b;
      end
      #600;
    end
  endtask

  logic ack_b;
  task automatic srelease_bit_ack;
    begin srelease(ack_b); end
  endtask

`ifdef VERILATOR
  // =====================================================================
  // v2.5 CRV instrumentation (Verilator only; iverilog path unchanged)
  // Tool notes (Verilator 5.006): no native FSM/SVA coverage and
  // randomize() ignores constraint blocks -> procedural constraints
  // ($urandom_range + rejection sampling), TB FSM probe, immediate
  // assertions.
  // =====================================================================
  localparam int SPMI_FSM_TOTAL = 6;  // ST_IDLE..ST_IGNORE (rtl enum)
  logic [7:0] fsm_seen = '0;          // visited-state bitmap
  wire  [2:0] dut_state = dut.state;  // hierarchical FSM probe
  wire        dut_sdoe  = dut.sd_oe;

  int sva_total = 0, sva_fail = 0;
  // counted immediate assertion: every evaluation is one check
  task automatic sva_check(input bit cond, input string name);
    begin
      sva_total++;
      if (!cond) begin
        sva_fail++;
        errors++;
        $display("SVA_FAIL: %s @%0t", name, $time);
      end
    end
  endtask

  // FSM coverage: sample DUT state register every clock
  always @(posedge clk) fsm_seen[dut_state] <= 1'b1;

  // output-invariant assertion suite (sampled coherently pre-NBA)
  logic [7:0] rx_byte_q = '0;
  logic       rx_valid_q = 0;
  int         rx_cnt = 0;             // scoreboard: rx_valid pulse count
  always @(posedge clk) begin
    if (rx_valid) rx_cnt <= rx_cnt + 1;
    if (!rst_n) begin
      // A1: outputs quiescent during reset
      sva_check(busy === 1'b0 && rx_valid === 1'b0 && dut_sdoe === 1'b0,
                "A1 reset: outputs quiescent");
    end else begin
      // A2: state register holds a legal enum encoding
      sva_check(dut_state <= 3'd5, "A2 state encoding legal");
      // A3: busy mirrors state (low in IDLE and IGNORE)
      sva_check(busy === ((dut_state != 3'd0) && (dut_state != 3'd5)),
                "A3 busy mirrors state");
      // A4: rx_valid is a single-cycle pulse
      sva_check(!(rx_valid && rx_valid_q), "A4 rx_valid single-cycle pulse");
      // A5: slave drives SDATA low only in the ACK/read phase or briefly
      // in IDLE while the last read bit drains (v2.5.1: sd_oe is released
      // on the first sclk fall after the ACKP->IDLE transition)
      sva_check(!dut_sdoe || (dut_state == 3'd4) || (dut_state == 3'd0),
                "A5 drive only in ACKP/IDLE-drain");
      // A6: rx_byte changes only on the cycle rx_valid is high
      sva_check((rx_byte === rx_byte_q) || rx_valid, "A6 rx_byte stable");
      // A7: rx_valid only mid-transaction (byte completes under busy)
      sva_check(!rx_valid || busy, "A7 rx_valid implies busy");
    end
    rx_byte_q  <= rx_byte;
    rx_valid_q <= rx_valid;
  end

  // ---- inlined bit-level macros for the random phase ------------------
  // (same Verilator 5.006 scheduler rationale as the I2C pilot: chained
  // timing-task coroutines can lose wakeups after ~2k awaits, so the
  // random phase runs as ONE coroutine with plain #awaits only)
  `define SPMI_M_BIT(b) \
    m_low = ~(b); #300; sclk = 1; #600; sclk = 0; #300;
  `define SPMI_M_RBIT(b) \
    m_low = 0; #300; sclk = 1; #300; b = sdata; #300; sclk = 0; #300;
  `define SPMI_M_SSC \
    m_low = 0; sclk = 1; #300; \
    m_low = 1; #300; \
    sclk = 0; #300; \
    m_low = 0; #300;
`endif

  logic [7:0] rb;
  initial begin
    rst_n = 0; repeat(10) @(posedge clk);
    rst_n = 1; repeat(10) @(posedge clk);

    spmi_write(4'h5, 8'h03, 8'h5A);
    repeat(5) @(posedge clk);
    if (!rx_seen) begin errors++; $display("ERROR: SPMI rx_valid never pulsed"); end
    if (rx_byte !== 8'h5A) begin errors++; $display("ERROR: SPMI rx=%h exp=5A", rx_byte); end
    if (rx_addr !== 8'h03) begin errors++; $display("ERROR: SPMI rx_addr=%h exp=03", rx_addr); end

    spmi_read (4'h5, 8'h03, rb);
    if (rb !== 8'hC2) begin errors++; $display("ERROR: SPMI read got=%h exp=C2", rb); end

    // v2.5.1: after a read with tx_byte[0]=0 the slave must release SDATA
    // -- a following write must still be received (bus-wedge regression)
    rx_seen = 1'b0;
    spmi_write(4'h5, 8'h04, 8'hA5);
    repeat(5) @(posedge clk);
    if (!rx_seen) begin errors++; $display("ERROR: SPMI bus wedge: post-read write ignored"); end
    if (rx_byte !== 8'hA5) begin errors++; $display("ERROR: SPMI post-read rx=%h exp=A5", rx_byte); end

`ifdef VERILATOR
    // ---- v2.5 CRV random phase (directed tests above untouched) ----
    // 130 randomized transactions: ~45% register write (rx_byte/rx_addr
    // compared, ACK bit checked, rx_valid pulse counted), ~35% register
    // read (must return tx_byte), ~10% wrong slave address (ignored),
    // ~10% illegal command (ignored). Fully inlined via the macros above
    // (single coroutine, plain #awaits).
    begin : crv_phase
      int n_wr = 0, n_rd = 0, n_wa = 0, n_ic = 0;
      int roll, rx_cnt_before;
      logic [3:0] sa, cmd_c;
      logic [7:0] ad, v, rd_c, bb;
      for (int t = 0; t < 130; t++) begin
        roll = $urandom_range(0, 15);
        v    = (roll == 0) ? 8'h00 : (roll == 1) ? 8'hFF
                                                 : 8'($urandom_range(0, 255));
        ad   = 8'($urandom_range(0, 255));
        roll = $urandom_range(0, 19);
        if (roll < 9) begin
          // ---- random write to our slave address ----
          n_wr++;
          rx_cnt_before = rx_cnt;
          `SPMI_M_SSC
          bb = 1'b0; `SPMI_M_BIT(bb) bb = 1'b1; `SPMI_M_BIT(bb)
          bb = 1'b0; `SPMI_M_BIT(bb) bb = 1'b1; `SPMI_M_BIT(bb)   // SA = 4'h5
          for (int i = 3; i >= 0; i--) begin bb = 1'b0;    `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin bb = ad[i];   `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin bb = v[i];    `SPMI_M_BIT(bb) end
          // ACK bit: the slave pulls SDATA low from the post-data SCLK
          // fall until the next SCLK rise, so sample during the low phase
          m_low = 0; #300;
          bb = sdata;
          sclk = 1; #600; sclk = 0; #300;
          if (bb !== 1'b0) begin
            errors++; $display("ERROR: CRV write no ACK (ad=%h v=%h)", ad, v);
          end
          #600;
          repeat (4) @(posedge clk);
          if (rx_cnt != rx_cnt_before + 1) begin
            errors++; $display("ERROR: CRV write no rx_valid (ad=%h v=%h)", ad, v);
          end
          if (rx_byte !== v) begin
            errors++; $display("ERROR: CRV rx_byte=%h exp=%h", rx_byte, v);
          end
          if (rx_addr !== ad) begin
            errors++; $display("ERROR: CRV rx_addr=%h exp=%h", rx_addr, ad);
          end
        end else if (roll < 16) begin
          // ---- random read: DUT must return tx_byte ----
          // v2.5.1: bus-wedge bug fixed (sd_oe is released on the sclk
          // fall after the last read bit), so read values are no longer
          // rejection-sampled to LSB=1.
          n_rd++;
          tx_byte = v;
          `SPMI_M_SSC
          bb = 1'b0; `SPMI_M_BIT(bb) bb = 1'b1; `SPMI_M_BIT(bb)
          bb = 1'b0; `SPMI_M_BIT(bb) bb = 1'b1; `SPMI_M_BIT(bb)   // SA = 4'h5
          bb = 0; `SPMI_M_BIT(bb) bb = 0; `SPMI_M_BIT(bb)
          bb = 0; `SPMI_M_BIT(bb) bb = 1; `SPMI_M_BIT(bb)   // CMD = read
          for (int i = 7; i >= 0; i--) begin bb = ad[i];   `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin `SPMI_M_RBIT(bb) rd_c[i] = bb; end
          #600;
          if (rd_c !== v) begin
            errors++; $display("ERROR: CRV read got=%h exp=%h", rd_c, v);
          end
        end else if (roll < 18) begin
          // ---- wrong slave address: must be ignored ----
          n_wa++;
          sa = 4'($urandom_range(0, 15));
          if (sa == 4'h5) sa = 4'h4;             // rejection sampling
          rx_cnt_before = rx_cnt;
          `SPMI_M_SSC
          for (int i = 3; i >= 0; i--) begin bb = sa[i]; `SPMI_M_BIT(bb) end
          for (int i = 3; i >= 0; i--) begin bb = 1'b0;  `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin bb = ad[i]; `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin bb = v[i];  `SPMI_M_BIT(bb) end
          #600;
          repeat (4) @(posedge clk);
          if (rx_cnt != rx_cnt_before) begin
            errors++; $display("ERROR: CRV wrong addr %h captured", sa);
          end
          if (busy) begin
            errors++; $display("ERROR: CRV busy stuck after wrong-addr frame");
          end
        end else begin
          // ---- illegal command (not 0/1): frame ignored after ADDR ----
          n_ic++;
          cmd_c = 4'($urandom_range(2, 15));     // rejection: never 0/1
          rx_cnt_before = rx_cnt;
          `SPMI_M_SSC
          bb = 1'b0; `SPMI_M_BIT(bb) bb = 1'b1; `SPMI_M_BIT(bb)
          bb = 1'b0; `SPMI_M_BIT(bb) bb = 1'b1; `SPMI_M_BIT(bb)   // SA = 4'h5
          for (int i = 3; i >= 0; i--) begin bb = cmd_c[i]; `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin bb = ad[i];    `SPMI_M_BIT(bb) end
          for (int i = 7; i >= 0; i--) begin bb = v[i];     `SPMI_M_BIT(bb) end
          #600;
          repeat (4) @(posedge clk);
          if (rx_cnt != rx_cnt_before) begin
            errors++; $display("ERROR: CRV illegal cmd %h captured", cmd_c);
          end
          if (busy) begin
            errors++; $display("ERROR: CRV busy stuck after illegal-cmd frame");
          end
        end
      end
      $display("CRV: 130 txns (wr=%0d rd=%0d wrong_addr=%0d ill_cmd=%0d)",
               n_wr, n_rd, n_wa, n_ic);
    end
  `undef SPMI_M_BIT
  `undef SPMI_M_RBIT
  `undef SPMI_M_SSC
`endif

    if (ack_b !== 1'b0) begin errors++; $display("ERROR: SPMI write not ACKed"); end

    // read data is the tx_byte value at the start of the read, even if
    // tx_byte changes while the bits are being shifted out
    tx_byte = 8'h96;
    fork
      spmi_read(4'h5, 8'h10, rb);
      begin #24000 tx_byte = 8'h00; end
    join
    if (rb !== 8'h96) begin errors++; $display("ERROR: SPMI read changed mid-byte: %h", rb); end

    // a new SSC in the middle of a frame restarts the frame
    rx_seen = 1'b0;
    ssc;
    sbit(0); sbit(1); sbit(0); sbit(1); sbit(0); sbit(0);
    spmi_write(4'h5, 8'h22, 8'h3C);
    repeat(5) @(posedge clk);
    if (!rx_seen || rx_byte !== 8'h3C || rx_addr !== 8'h22) begin
      errors++; $display("ERROR: SPMI restart by SSC failed rx=%h ad=%h", rx_byte, rx_addr);
    end

    // reset while the slave drives read data: bus released, frame dropped
    tx_byte = 8'h00;
    fork
      spmi_read(4'h5, 8'h11, rb);
      begin #25000 @(negedge clk) rst_n = 1'b0; #50;
        if (sdata !== 1'b1 || busy !== 1'b0) begin errors++; $display("ERROR: SPMI not released in reset"); end
        @(negedge clk) rst_n = 1'b1; end
    join
    spmi_write(4'h5, 8'h00, 8'h7E);            // lowest / highest register address
    spmi_write(4'h5, 8'hFF, 8'hE7);
    spmi_write(4'h5, 8'h05, 8'h81);
    repeat(5) @(posedge clk);
    if (rx_byte !== 8'h81 || ack_b !== 1'b0) begin errors++; $display("ERROR: SPMI after reset rx=%h", rx_byte); end

    // reads of registers 0x00 / 0xFF, an alternating-bit write, and SSCs
    // restarting a frame in the address and in the data field (the
    // restarted frame then completes normally)
    begin : frame_classes
      logic [7:0] d;
      logic [3:0] sa;
      sa = 4'h5;
      spmi_read(sa, 8'h00, d);
      spmi_read(sa, 8'hFF, d);
      spmi_write(sa, 8'h21, 8'h55);
      if (rx_byte !== 8'h55 || rx_addr !== 8'h21) begin
        errors++; $display("ERROR: SPMI alt write rx=%h addr=%h", rx_byte, rx_addr);
      end
      for (int k = 0; k < 2; k++) begin
        ssc;
        for (int i = 3; i >= 0; i--) sbit(sa[i]);
        sbit(0); sbit(0); sbit(0); sbit(0);
        for (int i = 0; i < 3 + 8 * k; i++) sbit(1'b1);
        spmi_write(sa, 8'h22 + 8'(k), 8'hA0 + 8'(k));
        if (rx_byte !== 8'hA0 + 8'(k) || rx_addr !== 8'h22 + 8'(k)) begin
          errors++; $display("ERROR: SPMI write after restart rx=%h addr=%h", rx_byte, rx_addr);
        end
      end
    end

    if (errors == 0) $display("TEST PASSED: SPMI");
    else             $display("TEST FAILED: %0d errors", errors);
`ifdef VERILATOR
    begin
      int visited;
      visited = 0;
      for (int s = 0; s < SPMI_FSM_TOTAL; s++) visited += fsm_seen[s];
      $display("FSM_COV: %0d/%0d", visited, SPMI_FSM_TOTAL);
      $display("SVA_CHECKS: %0d/%0d", sva_total - sva_fail, sva_total);
    end
`endif
    $finish;
  end

`ifdef VERILATOR
  // Chunked timeout: with Verilator 5.006 a single long-pending #delay
  // event corrupts the --timing delay heap once many short-delay
  // resumptions interleave with it (processes lose wakeups and the long
  // event fires early). 1-us chunks keep all heap entries short-lived.
  initial begin
    repeat (30000) #1000;   // 30 ms in 1-us chunks
    $display("TIMEOUT"); $finish;
  end
`else
  initial begin
    #3_000_000; $display("TIMEOUT"); $finish;
  end
`endif
endmodule
