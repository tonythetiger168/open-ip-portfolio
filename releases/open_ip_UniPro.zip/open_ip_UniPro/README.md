# UniPro Open IP

UniPro protocol -- MIPI UniPro 1.x data link layer (educational slice)
- 8-bit symbol serial tx/rx (start + 8 data LSB-first + stop, idle=1)
- ESC_DL escape (8'h9D, next byte XOR 0x20) + COF (8'h7E) frame delimiting
- L2 frame: hdr{tc[1],cport[4],seq[4],len[8]} + payload(<=16B) + CRC16
(poly 0x1021, init 0xFFFF, appended hi/lo, rx residue == 0)
- PACP control frames (get/set CPort attributes, 16x8 attr registers)
- data frame seq management: ACK / NAC -> retransmit <=3, ACK timeout
- TC0/TC1 dual TX queues, strict priority (TC1 first)
- received CPort0 data uplinks to 32x8 message buffer (cpu port)
CPU map: wr 0=push TC0, 1=push TC1, 2=PACP_SET{idx,val}, 3=PACP_GET{idx},
4=tx_cport
rd 4=msg buffer pop, 5=status{msg_cnt,q1_cnt,q0_cnt},
6={pacp_cnf,pacp_rsp_valid,pacp_rsp_val} (read clears flags)
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/UniPro_top.sv` -- synthesizable RTL (top: `UniPro_top`)
- `tb/UniPro_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/UniPro_yosys.ys` -- Yosys synthesis script
- `syn/UniPro_dc.tcl` -- Synopsys Design Compiler script
- `syn/UniPro.sdc` -- timing constraints
- `sim/filelist_UniPro.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
