# AXI Open IP

AXI (AXI3-style) protocol -- real AXI3 slave IP: 5 channel handshakes,
INCR/FIXED bursts (len 1..16, len field [3:0]), write data channel carries
WID (write interleaving NOT supported: WID must match the accepted AWID,
beats are processed strictly in order), byte strobes, true valid/ready
backpressure, SLVERR on out-of-range / misaligned / WRAP / WID mismatch,
DECERR on unsupported size/burst encoding. 256x32 register file target.
Simplifications: single outstanding transaction per direction, no write
interleaving, awsize <= log2(DW/8), WRAP treated as error.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/AXI_top.sv` -- synthesizable RTL (top: `AXI_top`)
- `tb/AXI_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/AXI_yosys.ys` -- Yosys synthesis script
- `syn/AXI_dc.tcl` -- Synopsys Design Compiler script
- `syn/AXI.sdc` -- timing constraints
- `sim/filelist_AXI.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
