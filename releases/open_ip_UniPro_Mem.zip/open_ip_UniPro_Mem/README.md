# UniPro_Mem Open IP

MIPI UniPro-Mem -- UniPro 1.x data-link layer (educational slice) with a
memory-mapped transaction-layer service.
* 8-bit symbol serial link, ESC_DL escape (8'h9D) + COF (8'hC0) framing
* L2 frame: hdr{tc,cport[3:0]}{seq[3:0]}{len[7:0]} payload(<=16B) CRC16(0x1021)
* CPort1 memory transactions: write/read of a 64x32 memory; a queued read
response that cannot start transmission within 100 clk is replaced by an
error frame (read timeout)
* PACP-style attribute get/set (16x8 regs) on CPort 0xF
* Outgoing data frames carry seq numbers; NAC triggers retransmit (<=3,
then irq). QoS: TC1 strict priority over TC0. irq: CRC error /
out-of-bounds / NAC retransmit exhausted.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/UniPro_Mem_top.sv` -- synthesizable RTL (top: `UniPro_Mem_top`)
- `tb/UniPro_Mem_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/UniPro_Mem_yosys.ys` -- Yosys synthesis script
- `syn/UniPro_Mem_dc.tcl` -- Synopsys Design Compiler script
- `syn/UniPro_Mem.sdc` -- timing constraints
- `sim/filelist_UniPro_Mem.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
