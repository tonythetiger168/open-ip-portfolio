# AXI4 Open IP

AXI4 protocol -- real AXI4 slave IP: 5 independent channel handshakes,
INCR/FIXED bursts (len 1..16), byte strobes, true valid/ready backpressure,
SLVERR on out-of-range / misaligned / WRAP, DECERR on unsupported ID/size/
burst/len. 256x32 register file as the slave memory target.
Simplifications: single outstanding transaction per direction, ID==0 only,
awsize <= log2(DW/8), WRAP treated as error.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/AXI4_top.sv` -- synthesizable RTL (top: `AXI4_top`)
- `tb/AXI4_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/AXI4_yosys.ys` -- Yosys synthesis script
- `syn/AXI4_dc.tcl` -- Synopsys Design Compiler script
- `syn/AXI4.sdc` -- timing constraints
- `sim/filelist_AXI4.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
