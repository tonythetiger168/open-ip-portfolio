# eUSB2 Open IP

eUSB2 protocol IP -- eUSB2 device/repeater (simplified)
* eD+/eD- single-ended 1.2V signalling, simplified to lvcmos logic
levels (J = 10, K = 01, SE0 = 00, SE1 = 11 illegal), 1 bit cell/clk
* USB2 packet-layer retimer: the received eUSB2 NRZI bit stream is
re-registered and driven onto the standard dp/dm output port
* Control messages (control packets, PID 8'hC3): register write/read
of an 8x8 register file (reg0 = squelch threshold, reg1 = term
config, reg2..7 scratch); read responses are transmitted as a
USB2-style frame on dp/dm
* Squelch detection: SE0 longer than the programmed threshold forces
the retimed outputs silent and resets the packet parser
* NRZI decode + bit unstuffing on receive; NRZI encode + bit stuffing
on transmit; CRC8 (poly 0x07, init 0xFF) protects control packets
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/eUSB2_top.sv` -- synthesizable RTL (top: `eUSB2_top`)
- `tb/eUSB2_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/eUSB2_yosys.ys` -- Yosys synthesis script
- `syn/eUSB2_dc.tcl` -- Synopsys Design Compiler script
- `syn/eUSB2.sdc` -- timing constraints
- `sim/filelist_eUSB2.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
