# WTB Open IP

WTB protocol -- IEEE 802.4 style token-bus station (educational slice)
Frame: preamble(8'h55 x2) + SD(8'hD5) + FC{0=claim,1=token,2=data,3=solicit}
+ DA + SA + LEN + payload(<=16B) + CRC16(0x1021,init 0xFFFF) + ED(8'hD4)
Serial rx/tx at 1 bit/clk (MSB first per byte), idle bus = 1.
Station FSM: LISTEN -> token(DA==my_addr) -> HOLD window (<=4 frames or
<=200 clk) -> data frames from 8x32 TX FIFO (cpu port) -> pass token to NS.
claim_token contention after bus-idle timeout with response window.
Bad CRC / bad ED / overlong frames are dropped + irq pulse.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/WTB_top.sv` -- synthesizable RTL (top: `WTB_top`)
- `tb/WTB_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/WTB_yosys.ys` -- Yosys synthesis script
- `syn/WTB_dc.tcl` -- Synopsys Design Compiler script
- `syn/WTB.sdc` -- timing constraints
- `sim/filelist_WTB.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
