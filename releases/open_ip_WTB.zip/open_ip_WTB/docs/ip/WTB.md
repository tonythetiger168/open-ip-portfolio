# IEEE 802.4-style token-bus station: serial frames with preamble, SD, FC, DA, SA, LEN, payload, CRC-16 and ED; token hold with up to four data frames inside a programmable window, token pass to the next station, claim_token contention, an 8-word TX FIFO and an 8-word RX FIFO

Protocol IP `WTB`, version 2.0. Apache-2.0.

| Item | Value |
|---|---|
| Core | `WTB_top` (`rtl/WTB_top.sv`) |
| Register interface | APB4 slave `WTB_apb`, 32-bit data, 12-bit byte address, zero wait states |
| Clock, reset | PCLK (rising edge), PRESETN (active low, asynchronous) |
| ID register | 0x57540200 (code 0x5754, version 2.0) |
| Registers | 12 words, 0x000 to 0x02C |
| Interrupts | 1 sources into one level-high `irq` |
| Core register port | CORE (5 words) |
| Protocol pins | 3 pass-through |

## Overview

WTB protocol -- IEEE 802.4 style token-bus station (educational slice) Frame: preamble(8'h55 x2) + SD(8'hD5) + FC{0=claim,1=token,2=data,3=solicit} + DA + SA + LEN + payload(<=16B) + CRC16(0x1021,init 0xFFFF) + ED(8'hD4) Serial rx/tx at 1 bit/clk (MSB first per byte), idle bus = 1. Station FSM: LISTEN -> token(DA==my_addr) -> HOLD: data frames (4-byte payload) from the 8x32 TX FIFO while fewer than MAX_FR frames were sent and the hold time is below the programmable window -> pass token to NS. claim_token contention after bus-idle timeout with response window: a claim from a lower address wins (we back off), a claim from a higher address is ignored, other traffic ends the attempt. The station hears its own frames on the bus; frames with SA == my_addr are ignored. Data frames for my_addr (or broadcast DA 8'hFF) with a good CRC and ED are delivered to an 8x32 RX FIFO: payload bytes packed big-endian into words, the last word zero-padded; a word that does not fit is dropped with irq. irq (1-clk pulse): bad CRC / bad ED / overlong frame, TX FIFO overflow, RX FIFO overflow, token acquired.

rx_bit (serial in, 1 bit per PCLK, idle 1; the station hears its own frames), tx_bit and tx_en pass through unchanged.
NS, DA and CTRL are write-only in the core and read back as 0. A write with PSTRB != 4'hF to a core word is dropped with PSLVERR.

## Files

| File | Content |
|---|---|
| `rtl/WTB_top.sv` | protocol core |
| `rtl/WTB_apb.sv` | APB4 register wrapper (generated) |
| `tb/WTB_tb.sv` | core testbench |
| `tb/WTB_apb_tb.sv`, `tb/apb/WTB_apb_func.svh` | wrapper testbench (generated part + IP-specific part) |
| `tb/cov/WTB_sva.sv`, `tb/cov/WTB_apb_sva.sv` | coverage checkers (core, wrapper) |
| `scripts/apb/specs/WTB.json` | register spec the wrapper, TB, checker and this page are generated from |

How to run the tests and the coverage flow: see [Running and verifying](#running-and-verifying).

## Parameters

`WTB_apb` has the core's parameters and passes them to `WTB_top` unchanged.

| Parameter | Type | Default |
|---|---|---|
| `IDLE_TO` | int | `300` |
| `CLAIM_WIN` | int | `150` |
| `HOLD_WIN` | int | `400` |
| `MAX_FR` | int | `4` |

## Wrapper pins

Pins of `WTB_apb`. Widths of the pass-through pins are at the default parameters.

| Pin | Dir | Width | Description |
|---|---|---|---|
| `PCLK` | input | 1 | APB clock; also the core clock |
| `PRESETN` | input | 1 | APB reset, active low; also the core reset |
| `PSEL` | input | 1 | slave select |
| `PENABLE` | input | 1 | access phase |
| `PWRITE` | input | 1 | 1 = write, 0 = read |
| `PADDR` | input | 12 | byte address; bits [1:0] must be 0 |
| `PWDATA` | input | 32 | write data |
| `PSTRB` | input | 4 | write byte strobes |
| `PRDATA` | output | 32 | read data |
| `PREADY` | output | 1 | always high in the access phase (no wait states) |
| `PSLVERR` | output | 1 | error: unmapped or misaligned address, or partial write to a core register word |
| `irq` | output | 1 | interrupt, level high: \|(IRQ_STATUS & IRQ_ENABLE) |
| `rx_bit` | input | 1 | protocol pin, core port `rx_bit` |
| `tx_bit` | output | 1 | protocol pin, core port `tx_bit` |
| `tx_en` | output | 1 | protocol pin, core port `tx_en` |

## Core ports

| Port | Dir | Width | In the APB wrapper |
|---|---|---|---|
| `clk` | input | 1 | PCLK |
| `rst_n` | input | 1 | PRESETN |
| `rx_bit` | input | 1 | pin (pass-through) |
| `tx_bit` | output | 1 | pin (pass-through) |
| `tx_en` | output | 1 | pin (pass-through) |
| `my_addr` | input | 8 | MYADDR[7:0] |
| `cpu_we` | input | 1 | write to a CORE word |
| `cpu_addr` | input | 2 | CORE word index |
| `cpu_wdata` | input | 32 | CORE write data |
| `cpu_re` | input | 1 | read of a CORE word |
| `cpu_rdata` | output | 32 | CORE read data |
| `fifo_count` | output | 4 | STATUS[3:0] |
| `rx_count` | output | 4 | STATUS[7:4] |
| `token_held` | output | 1 | STATUS[8:8] |
| `irq` | output | 1 | IRQ_STATUS.EVT |

## APB wrapper

`WTB_apb` is an APB4 slave (AMBA APB protocol v2.0): zero wait states, 32-bit data, 12-bit byte address, PSTRB byte lanes on every writable register, PSLVERR on an unmapped or misaligned address (reads then return 0, writes are dropped). Writes to read-only registers are ignored without an error. The core runs on PCLK and PRESETN. `irq` is level-high: `|(IRQ_STATUS & IRQ_ENABLE)`.

Pass-through pins: `rx_bit`, `tx_bit`, `tx_en`.

### Register map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| 0x000 | ID | RO | 0x57540200 | IP identification: code, major and minor version |
| 0x004 | IRQ_STATUS | W1C | 0x00000000 | Sticky interrupt bits, write 1 to clear |
| 0x008 | IRQ_ENABLE | RW | 0x00000000 | Interrupt enables; irq = \|(IRQ_STATUS & IRQ_ENABLE) |
| 0x00C | FLAGS | RO | 0x00000000 | Stream holding-register state |
| 0x010 | SCRATCH | RW | 0x00000000 | Scratch register, no effect on the core |
| 0x014 | MYADDR | RW | 0x00000011 | Station identity |
| 0x018 | STATUS | RO | core | Station state |
| 0x01C | TXF | WO (core) | core | push one 32-bit word (the payload of one 4-byte data frame) onto the TX FIFO; a push to a full FIFO is dropped with EVT |
| 0x020 | NS | WO (core) | core | [7:0] next station: DA of the token pass |
| 0x024 | DA | WO (core) | core | [7:0] DA of the data frames |
| 0x028 | CTRL | WO (core) | core | [16:8] token holding window in clocks, [0] claim_en (claim the token after 300 idle clocks) |
| 0x02C | RXF | RO (core) | core | RX FIFO head: received payload bytes packed big-endian, the last word zero-padded; the read pops it |

Unlisted bits read 0 and ignore writes. Reset "core": the register reads the core's outputs directly, so after reset it shows the core's own reset state. WO (pulse) registers read 0. Offsets from 0x030 up to 0xFFC are unmapped (PSLVERR).

### Fields

| Register | Bits | Field | Access | Reset | Description |
|---|---|---|---|---|---|
| ID | 31:16 | CODE | RO | 0x5754 | IP code |
| ID | 15:8 | MAJOR | RO | 0x02 | major version |
| ID | 7:0 | MINOR | RO | 0x00 | minor version |
| IRQ_STATUS | 0 | one bit per interrupt | W1C | 0x0 | see Interrupts |
| IRQ_ENABLE | 0 | one bit per interrupt | RW | 0x0 | 1 enables the IRQ_STATUS bit onto `irq` |
| SCRATCH | 31:0 | SCRATCH | RW | 0x00000000 | free for software |
| MYADDR | 7:0 | `my_addr` | RW | 0x11 | this station's bus address (DA of its tokens and data, SA of its frames) |
| STATUS | 3:0 | `fifo_count` | RO | core | TX FIFO words (0..8) |
| STATUS | 7:4 | `rx_count` | RO | core | RX FIFO words (0..8) |
| STATUS | 8 | `token_held` | RO | core | the station holds the token |
| TXF | 31:0 | core register | WO (core) | core | written at core register 0 |
| NS | 31:0 | core register | WO (core) | core | written at core register 1 |
| DA | 31:0 | core register | WO (core) | core | written at core register 2 |
| CTRL | 31:0 | core register | WO (core) | core | written at core register 3 |
| RXF | 31:0 | core register | RO (core) | core | read from core register 0 |

### Interrupts (IRQ_STATUS, IRQ_ENABLE)

A bit is set while its source is active, stays set until written with 1, and a set in the same clock as the clear wins.

| Bit | Name | Set when |
|---|---|---|
| 0 | EVT | token acquired, or an error: bad CRC, bad ED or overlong frame received, TX FIFO overflow, RX FIFO overflow |

### Core register port

The CORE words reach the core's own register port. A write to one pulses `cpu_we` for one clock with `cpu_addr` (the core register) and `cpu_wdata` (PWDATA's low bits); it must cover the whole word (PSTRB = 4'hF): a partial write is dropped with PSLVERR. A read drives `cpu_addr` (the core register) and pulses `cpu_re` during the access phase and returns `cpu_rdata`.

## Programming sequence

1. Release PRESETN. Read ID (0x000) and check it is 0x57540200.
2. Write 0x1 to IRQ_STATUS (0x004) to clear any stale bits.
3. Configure the core: write MYADDR (0x014). Reset values are in the register map; PSTRB selects the bytes written.
4. Write IRQ_ENABLE (0x008) with the interrupts to use (bit order as in the Interrupts table; 0x1 enables all).
5. Read STATUS (0x018) for the core's live `fifo_count`, `rx_count`, `token_held`; it needs no clearing.
6. Access the core's registers through the CORE words (0x01C onward), one word per core register; write whole words (PSTRB = 0xF), a partial write is dropped with PSLVERR.
7. On `irq`: read IRQ_STATUS, handle every bit that is set and enabled, then write those bits back to IRQ_STATUS to clear them. A source that is still active sets its bit again.

## Running and verifying

All commands run from the repository root. Icarus Verilog 12 and Yosys 0.33 are enough for steps 1 to 3; step 4 also needs Verilator 5.052 and pyslang (see [README, Setup](../../README.md#setup)).

| Step | Command | Pass when | Output |
|---|---|---|---|
| 1. Core test | `make -f Makefile.WTB sim` | a `TEST PASSED` line, no `ERROR` | console |
| 2. Core synthesis | `make -f Makefile.WTB syn` | Yosys ends without `ERROR`; `stat` prints the cell count | `work/WTB_top.json` |
| 3. APB wrapper test + synthesis | `make -f Makefile.WTB apb` | `TEST PASSED: WTB_apb`, then Yosys without `ERROR` | console, `work/WTB_apb.json` |
| 4. Coverage (core, wrapper) | `bash scripts/cov/run_cov.sh WTB`<br>`bash scripts/cov/run_cov.sh WTB_apb` | `RESULT: CLOSED` (all five metrics 100%) | `work/cov/WTB/score.json`, `work/cov/WTB_apb/score.json` |

Expected end of a step 4 run:

```
===== WTB =====
TEST: PASSED   SVA_FAILURES: 0
LINE ... TOGGLE ... FSM ... SVA ... FUNCTIONAL  (each n/n, 100.0%)
RESULT: CLOSED
```

**Core test** (`tb/WTB_tb.sv`): drives `WTB_top` through its own ports against a protocol peer or model and checks every result itself; any mismatch prints `ERROR`, and `TEST PASSED` is printed only when there were none.

**APB wrapper test** (`tb/WTB_apb_tb.sv`), in this order:

1. Reset values of every register, ID included.
2. Writes to read-only registers are ignored.
3. Each RW register: all ones, all zeros, then 16 random writes with every PSTRB byte-lane pattern, read back each time.
4. Unmapped and misaligned addresses, reads and writes: PSLVERR, read data 0, no side effect on other registers.
5. Back-to-back transfers with no idle cycle.
6. IP traffic through the registers only (`tb/apb/WTB_apb_func.svh`): the programming sequence above, every interrupt bit set, enabled and cleared (100% wrapper toggle coverage confirms each bit moved).
7. PRESETN asserted mid-run: `irq` and PRDATA go to 0, registers return to reset values.

**Checkers** (`tb/cov/WTB_sva.sv`, `tb/cov/WTB_apb_sva.sv`): SVA protocol and APB assertions plus covergroups, bound in by the coverage flow. An assertion failure prints `SVA_FAIL` and fails the run even when the test itself passed.

Whole portfolio: `bash scripts/ci_regression.sh` runs steps 1 to 3 for every IP (what CI runs), and `bash scripts/cov/run_all.sh 4` runs step 4 for every IP.

## Verification

Five-metric coverage with Verilator 5.052 (`scripts/cov/run_cov.sh`); see [COVERAGE_CLOSURE.md](../COVERAGE_CLOSURE.md) for the flow. Line and toggle count only the named RTL file.

| Scope | Test | Line | Toggle | FSM | SVA | Functional |
|---|---|---|---|---|---|---|
| core `rtl/WTB_top.sv` | pass | 105/105 | 2140/2140 | 59/59 | 8/8 | 60/60 |
| wrapper `rtl/WTB_apb.sv` | pass | 24/24 | 594/594 | n/a | 12/12 | 38/38 |
