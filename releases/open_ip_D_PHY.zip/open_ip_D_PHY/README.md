# D_PHY Open IP

MIPI D-PHY lane-pair (clock lane + data lane) TX with same-lane RX decoder
Implementation scope:
* LP mode line levels on data lane (lp_p/lp_n): LP-11 STOP, LP-01
HS-Request, LP-00 Sync/Bridge, LP-10 used by escape entry/exit.
Simplification: each LP state / line bit lasts exactly 1 clk cycle.
* HS mode: SoT sequence LP-11 -> LP-01 -> LP-00 -> HS-0, sync byte
8'hB8 sent LSB-first (wire pattern 00011101), payload bytes LSB-first
on differential hs_p/hs_n, EoT = last payload bit inverted for one
bit time + one bit of the last level (HS-0/1), then LP-11.
* Escape mode: entry LP-10 -> LP-00 -> LP-01 -> LP-00, then 8-bit
escape command LSB-first (LP-10 = '1', LP-00 = '0'; the real
spaced-one-hot encoding is simplified to 1 bit/clk, see MIPI D-PHY
spec 8.4). Commands: LPDT 8'h87 (followed by LPDT data bytes, same
1 bit/clk encoding, LP-01 space marks end of data), ULPS 8'h78
(lines held LP-00 until esc_release), Trigger-Reset 8'h46 (4-clk
Mark-1 LP-00 then exit). Exit: [LP-01 space for LPDT] -> LP-10 ->
LP-11.
* Clock lane follows the data-lane HS sequence simultaneously (real
PHY starts the HS clock earlier; simplified) and toggles a
differential HS clock during the HS burst.
* RX side decodes the same lane (TB wires TX pads back to RX inputs):
HS sync check + payload byte reassembly, escape entry/command/LPDT
decode, ULPS detect. Protocol violations (bad HS sync, unknown
escape command, illegal LP sequence) raise sticky irq.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/D_PHY_top.sv` -- synthesizable RTL (top: `D_PHY_top`)
- `tb/D_PHY_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/D_PHY_yosys.ys` -- Yosys synthesis script
- `syn/D_PHY_dc.tcl` -- Synopsys Design Compiler script
- `syn/D_PHY.sdc` -- timing constraints
- `sim/filelist_D_PHY.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
