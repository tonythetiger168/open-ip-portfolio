# Avalon_MM Open IP

Avalon-MM slave -- real protocol IP design
Scope : Avalon-MM slave with waitrequest backpressure (slow window =
1 wait state), read & write bursts (burstcount <= 16, INCR),
in-order readdatavalid return, byteenable partial-write merge,
out-of-range burst truncation (writes dropped / read data cut)
+ sticky irq, 256x32 regfile.
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/Avalon_MM_top.sv` -- synthesizable RTL (top: `Avalon_MM_top`)
- `tb/Avalon_MM_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/Avalon_MM_yosys.ys` -- Yosys synthesis script
- `syn/Avalon_MM_dc.tcl` -- Synopsys Design Compiler script
- `syn/Avalon_MM.sdc` -- timing constraints
- `sim/filelist_Avalon_MM.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
