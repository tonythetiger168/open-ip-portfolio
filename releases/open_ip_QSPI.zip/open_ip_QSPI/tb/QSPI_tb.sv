// SPDX-License-Identifier: Apache-2.0
// Self-checking testbench: TB acts as QSPI master -- SystemVerilog
`timescale 1ns/1ps
module QSPI_tb;
  logic clk = 0, rst_n = 0;
  logic sclk = 0, csn = 1;
  tri  [3:0] io;
  logic [3:0] drv_val = 0;
  logic       drv_en  = 0;
  logic [3:0] drv_mask = 4'hF;   // which io bits the master drives when drv_en
  logic wen = 0, ren = 0;
  logic [3:0] waddr = 0, raddr = 0;
  logic [7:0] wdata = 0, rdata;
  int errors = 0;

  QSPI_top dut (
    .clk(clk), .rst_n(rst_n), .sclk(sclk), .csn(csn), .io(io),
    .wen(wen), .waddr(waddr), .wdata(wdata),
    .ren(ren), .raddr(raddr), .rdata(rdata), .irq());

  always #5 clk = ~clk;
  // per-bit master drivers (no z constants in drv_val: Verilator's tristate
  // lowering mishandles a variable assigned z from several places)
  for (genvar i = 0; i < 4; i++) begin : g_mdrv
    assign io[i] = (drv_en && drv_mask[i]) ? drv_val[i] : 1'bz;
  end

`ifdef VERILATOR
  // =====================================================================
  // v2.5 CRV instrumentation (tool build only; iverilog path unchanged)
  // QSPI_top is a shift-register datapath (mode/dir regs + counters): NO
  // FSM present, so FSM coverage is N/A (docs/coverage/W6_REST.md).
  // =====================================================================
  int sva_total = 0, sva_fail = 0;
  // counted immediate assertion: every evaluation is one check
  task automatic sva_check(input bit cond, input string name);
    begin
      sva_total++;
      if (!cond) begin
        sva_fail++;
        errors++;
        $display("SVA_FAIL: %s @%0t", name, $time);
      end
    end
  endtask

  // output-invariant assertion suite (sampled coherently pre-NBA)
  logic csn_q = 1'b1, irq_q = 1'b0;
  logic [1:0] mode_q = '0;
  always @(posedge clk) begin
    if (!rst_n) begin
      // A1: outputs quiescent during reset
      sva_check(dut.irq === 1'b0 && rdata === 8'h00, "A1 reset: outputs quiescent");
    end else begin
      // A2: rdata has no X/Z once out of reset
      sva_check(!$isunknown(rdata), "A2 rdata never X/Z");
      // A3: raddr==1 always reads back the TX register
      sva_check((raddr != 4'd1) || (rdata === dut.tx_q), "A3 raddr1 reads tx_q");
      // A4: irq is a single-cycle pulse
      sva_check(!(dut.irq && irq_q), "A4 irq single-cycle pulse");
      // A5: bit/nibble counters cleared one cycle after csn deasserts
      sva_check(!csn_q || (dut.bit_cnt == 3'd0 && dut.qcnt == 2'd0),
                "A5 counters clear under csn");
      // A6: illegal read addresses return zero
      sva_check((raddr <= 4'd1) || (rdata === 8'h00), "A6 illegal addr reads 0");
      // A7: in steady std mode only io[1] (MISO) is driven
      sva_check((dut.mode != 2'd0) || (dut.io_oe === 4'b0010),
                "A7 std mode drives MISO only");
    end
    csn_q  <= csn;
    irq_q  <= dut.irq;
    mode_q <= dut.mode;
  end
`endif

  task automatic wr(input logic [3:0] a, input logic [7:0] d);
    begin
      @(negedge clk); wen <= 1'b1; waddr <= a; wdata <= d;
      @(negedge clk); wen <= 1'b0;
    end
  endtask
  task automatic rd(input logic [3:0] a, output logic [7:0] d);
    begin
      @(negedge clk); ren <= 1'b1; raddr <= a;
      #1 d = rdata;
      @(negedge clk); ren <= 1'b0;
    end
  endtask

  task automatic std_xfer(input logic [7:0] din, output logic [7:0] dout);
    begin
      csn = 1'b0; drv_en = 1'b1; drv_mask = 4'b0001;   // MOSI only
      for (int i = 0; i < 8; i++) begin
        drv_val = {3'b000, din[7-i]};
        #40 sclk = 1'b1;
        #1 dout[7-i] = io[1];
        #39 sclk = 1'b0;
      end
      drv_en = 1'b0; csn = 1'b1; #100;
    end
  endtask

  task automatic quad_read(output logic [7:0] dout);
    begin
      csn = 1'b0; drv_en = 1'b0;          // release: slave drives io
      for (int i = 0; i < 2; i++) begin
        #40 sclk = 1'b1;
        #1 dout[7-4*i -: 4] = io[3:0];
        #39 sclk = 1'b0;
      end
      csn = 1'b1; #100;
    end
  endtask

  task automatic quad_write(input logic [7:0] din);
    begin
      csn = 1'b0; drv_en = 1'b1; drv_mask = 4'b1111;
      for (int i = 0; i < 2; i++) begin
        drv_val = din[7-4*i -: 4];
        #40 sclk = 1'b1; #1; #39 sclk = 1'b0;
      end
      drv_en = 1'b0; csn = 1'b1; #100;
    end
  endtask

  logic [7:0] d1, q1, q2, got;
  initial begin
    rst_n = 0; repeat(5) @(posedge clk);
    rst_n = 1; repeat(5) @(posedge clk);

    // standard mode
    wr(4'd0, 8'h3C);
    std_xfer(8'h00, d1);
    rd(4'd0, got);
    if (d1 !== 8'h3C) begin errors++; $display("ERROR: QSPI std MISO got=%h exp=3C", d1); end

    // v2.5.1 regression: std-mode tx_q[4]=1 must not disturb master MOSI
    wr(4'd0, 8'h10);
    std_xfer(8'hA5, d1);
    rd(4'd0, got);
    if (got !== 8'hA5) begin errors++; $display("ERROR: QSPI std MOSI (tx_q[4]=1) got=%h exp=A5", got); end
    if (d1 !== 8'h10) begin errors++; $display("ERROR: QSPI std MISO (tx_q[4]=1) got=%h exp=10", d1); end

    // quad mode: read slave tx, then write
    wr(4'd2, 8'h01);
    wr(4'd0, 8'hA7);
    wr(4'd3, 8'h00);          // dir = slave drives (read)
    quad_read(q1);
    wr(4'd3, 8'h01);          // dir = release (write)
    quad_write(8'h5A);
    rd(4'd0, got);
    if (q1 !== 8'hA7) begin errors++; $display("ERROR: QSPI quad read got=%h exp=A7", q1); end
    if (got !== 8'h5A) begin errors++; $display("ERROR: QSPI quad write got=%h exp=5A", got); end

`ifdef VERILATOR
    // ---- v2.5 CRV random phase (directed tests above untouched) ----
    // 120 randomized transactions over four classes: std full-duplex,
    // quad read, quad write (with random non-std mode encodings 1/2/3),
    // and illegal-address write/read injection; self-checked against the
    // programmed tx_q and the shifted-in rx_q.
    begin : crv_phase
      int n_std = 0, n_qr = 0, n_qw = 0, n_ill = 0;
      logic [7:0] tv, dv, dout_c;
      logic [3:0] ra;
      logic [1:0] md;
      int roll;
      // v2.5.1: the std-mode io[0] contention (io_oe used as a boolean)
      // is fixed; std-mode tx values are no longer constrained to bit4=0,
      // and the post-loop demo now checks the corrected behaviour.
      for (int t = 0; t < 120; t++) begin
        roll = $urandom_range(0, 11);
        tv = $urandom_range(0, 255);
        dv = $urandom_range(0, 255);
        if (roll < 1) begin
          // error injection: unimplemented address write/read, ignored
          n_ill++;
          ra = $urandom_range(4, 15);
          wr(ra, dv);
          rd(ra, dout_c);
          if (dout_c !== 8'h00) begin
            errors++; $display("ERROR: CRV illegal addr %0d read=%h exp=00", ra, dout_c);
          end
          wr(4'd2, 8'h00);            // back to std, tx_q must be intact
          rd(4'd1, dout_c);
          wr(4'd0, tv);
          repeat (2) @(posedge clk);  // let the DUT present the new first bit
          std_xfer(8'h00, dv);
          if (dv !== tv) begin
            errors++; $display("ERROR: CRV illegal write disturbed tx_q");
          end
        end else if (roll < 5) begin
          // standard-mode random frame
          n_std++;
          wr(4'd2, 8'h00);
          wr(4'd0, tv);
          repeat (2) @(posedge clk);  // let the DUT present the new first bit
          std_xfer(dv, dout_c);
          if (dout_c !== tv) begin
            errors++; $display("ERROR: CRV std MISO got=%h exp=%h", dout_c, tv);
          end
          rd(4'd0, got);
          if (got !== dv) begin
            errors++; $display("ERROR: CRV std MOSI got=%h exp=%h", got, dv);
          end
        end else if (roll < 8) begin
          // quad read with a random non-std mode encoding (1/2/3 all quad)
          n_qr++;
          md = $urandom_range(1, 3);
          wr(4'd2, {6'b0, md});
          wr(4'd0, tv);
          wr(4'd3, 8'h00);
          repeat (2) @(posedge clk);  // let the DUT present the new first nibble
          quad_read(dout_c);
          if (dout_c !== tv) begin
            errors++; $display("ERROR: CRV quad read got=%h exp=%h (mode=%0d)", dout_c, tv, md);
          end
        end else begin
          // quad write, then read back rx_q
          n_qw++;
          wr(4'd2, 8'h01);
          wr(4'd3, 8'h01);
          repeat (2) @(posedge clk);  // settle dir/mode before the frame
          quad_write(dv);
          rd(4'd0, got);
          if (got !== dv) begin
            errors++; $display("ERROR: CRV quad write got=%h exp=%h", got, dv);
          end
        end
      end
      $display("CRV: 120 txns (std=%0d quad_rd=%0d quad_wr=%0d illegal=%0d)",
               n_std, n_qr, n_qw, n_ill);
      // v2.5.1 regression lock (was the RTL-bug demo, see W6_REST.md):
      // with tx_q[4]=1 the fixed per-bit OE leaves io[0] to the master,
      // so MOSI shifts in cleanly and MISO returns tx_q.
      begin
        logic [7:0] demo_d, demo_g;
        wr(4'd2, 8'h00);
        wr(4'd0, 8'h10);            // tx_q[4] = 1
        repeat (2) @(posedge clk);
        std_xfer(8'hA5, demo_d);
        rd(4'd0, demo_g);
        if (demo_g !== 8'hA5) begin
          errors++;
          $display("ERROR: CRV std MOSI with tx_q[4]=1 got=%h exp=a5", demo_g);
        end
        if (demo_d !== 8'h10) begin
          errors++;
          $display("ERROR: CRV std MISO with tx_q[4]=1 got=%h exp=10", demo_d);
        end
      end
    end
`endif

    // two-byte quad read under one CSn: the high nibble is re-presented on
    // the falling edge after the byte boundary
    wr(4'd2, 8'h01); wr(4'd0, 8'hC4); wr(4'd3, 8'h00);
    repeat (2) @(posedge clk);
    begin
      logic [15:0] q16;
      csn = 1'b0; drv_en = 1'b0;
      for (int i = 0; i < 4; i++) begin
        #40 sclk = 1'b1;
        #1 q16[15-4*i -: 4] = io[3:0];
        #39 sclk = 1'b0;
      end
      csn = 1'b1; #100;
      if (q16 !== 16'hC4C4) begin errors++; $display("ERROR: QSPI 2-byte quad read got=%h", q16); end
    end
    // std frame aborted after 3 bits, then a clean frame
    wr(4'd2, 8'h00); wr(4'd0, 8'h96);
    csn = 1'b0; drv_en = 1'b1; drv_mask = 4'b0001;
    for (int i = 0; i < 3; i++) begin drv_val = 4'b0001; #40 sclk = 1'b1; #40 sclk = 1'b0; end
    drv_en = 1'b0; csn = 1'b1; #100;
    std_xfer(8'h3E, d1);
    rd(4'd0, got);
    if (d1 !== 8'h96 || got !== 8'h3E) begin
      errors++; $display("ERROR: QSPI post-abort frame miso=%h mosi=%h", d1, got);
    end
    // data-class sweep per transfer kind: std (every MOSI x MISO class
    // pair), quad read (each TX class), quad write (each RX class); then an
    // abort after each std bit count and after one nibble in both quad kinds
    begin : data_sweep
      logic [7:0] dv [4];
      logic [7:0] tv [4];
      logic [7:0] o;
      dv[0] = 8'h00; dv[1] = 8'hFF; dv[2] = 8'h55; dv[3] = 8'hC3;
      tv[0] = 8'h00; tv[1] = 8'hFF; tv[2] = 8'hAA; tv[3] = 8'h3C;
      wr(4'd2, 8'h00);
      for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++) begin
          wr(4'd0, tv[j]); std_xfer(dv[i], o); rd(4'd0, got);
          if (o !== tv[j] || got !== dv[i]) begin
            errors++; $display("ERROR: QSPI std sweep miso=%h/%h mosi=%h/%h", o, tv[j], got, dv[i]);
          end
        end
      wr(4'd2, 8'h01); wr(4'd3, 8'h00);
      for (int j = 0; j < 4; j++) begin
        wr(4'd0, tv[j]); quad_read(o);
        if (o !== tv[j]) begin errors++; $display("ERROR: QSPI quad-read sweep got=%h exp=%h", o, tv[j]); end
      end
      wr(4'd3, 8'h01);
      for (int i = 0; i < 4; i++) begin
        quad_write(dv[i]); rd(4'd0, got);
        if (got !== dv[i]) begin errors++; $display("ERROR: QSPI quad-write sweep got=%h exp=%h", got, dv[i]); end
      end
      wr(4'd2, 8'h00);
      for (int n = 1; n < 8; n++) begin
        wr(4'd0, 8'h96);
        csn = 1'b0; drv_en = 1'b1; drv_mask = 4'b0001;
        for (int i = 0; i < n; i++) begin drv_val = {3'b000, i[0]}; #40 sclk = 1'b1; #40 sclk = 1'b0; end
        drv_en = 1'b0; csn = 1'b1; #100;
        std_xfer(8'h69, o); rd(4'd0, got);
        if (o !== 8'h96 || got !== 8'h69) begin
          errors++; $display("ERROR: QSPI abort@%0d miso=%h mosi=%h", n, o, got);
        end
      end
      for (int k = 0; k < 2; k++) begin
        wr(4'd2, 8'h01); wr(4'd3, {7'd0, k[0]}); wr(4'd0, 8'h5C);
        csn = 1'b0; drv_en = k[0]; drv_mask = 4'b1111; drv_val = 4'h9;
        #40 sclk = 1'b1; #40 sclk = 1'b0;
        drv_en = 1'b0; csn = 1'b1; #100;
        if (k == 0) begin
          quad_read(o);
          if (o !== 8'h5C) begin errors++; $display("ERROR: QSPI quad-read after abort got=%h", o); end
        end else begin
          quad_write(8'h3A); rd(4'd0, got);
          if (got !== 8'h3A) begin errors++; $display("ERROR: QSPI quad-write after abort got=%h", got); end
        end
      end
    end

    // reset mid-frame
    wr(4'd2, 8'h00);
    csn = 1'b0;
    #40 sclk = 1'b1; #40 sclk = 1'b0;
    @(negedge clk) rst_n = 1'b0;
    #1;
    if (dut.irq !== 1'b0 || dut.io_oe !== 4'b0010) begin errors++; $display("ERROR: QSPI not idle in reset"); end
    csn = 1'b1; drv_en = 1'b0;
    @(negedge clk) rst_n = 1'b1;

    if (errors == 0) $display("TEST PASSED: QSPI");
    else             $display("TEST FAILED: %0d errors", errors);
`ifdef VERILATOR
    $display("FSM_COV: N/A (no FSM: shift-register datapath)");
    $display("SVA_CHECKS: %0d/%0d", sva_total - sva_fail, sva_total);
`endif
    $finish;
  end

`ifdef VERILATOR
  // chunked timeout guard: a single long-pending #delay event corrupts the
  // 5.006 --timing delay heap once many short-delay resumptions interleave;
  // chunked delays keep all heap entries short-lived (see docs/COVERAGE.md)
  initial begin
    repeat (3000) #1000;   // 3 ms in 1-us chunks
    $display("TIMEOUT"); $finish;
  end
`else
  initial begin
    #1_000_000; $display("TIMEOUT"); $finish;
  end
`endif
endmodule
