# APB Open IP

APB3 slave -- real two-phase IDLE/SETUP/ACCESS protocol, pready wait
states (slow region), pslverr on reserved region, 256x32 register file
Open IP design implementation v2.3 -- Apache-2.0
Address map (byte addresses):
0x000-0x3FF : fast region, zero wait state   (256 x 32 register file)
0x400-0x7FF : slow region, one wait state    (same register file)
0x800+      : reserved  -> pslverr at completion + irq event

## Package contents

- `rtl/APB_top.sv` -- synthesizable RTL (top: `APB_top`)
- `tb/APB_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/APB_yosys.ys` -- Yosys synthesis script
- `syn/APB_dc.tcl` -- Synopsys Design Compiler script
- `syn/APB.sdc` -- timing constraints
- `sim/filelist_APB.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
