# USB3 Open IP

USB3 protocol IP -- SuperSpeed link + protocol layer (simplified)
* Symbol-parallel serial link: 1 symbol/clk, 8-bit symbol, on the
tx_p/tx_n and rx_p/rx_n differential pairs (_n carries the complement)
* LFPS out-of-band handshake: RXDET -> Polling.LFPS burst/idle counting
-> U0 (link_up). LFPS burst = repeated 8'hAA symbols, idle = 8'h00.
* Ordered-set framing:
DPH : SOF(8'hBC) + {route,type} + {seq,blk} + CRC5
DPP : START(8'h5A) + fixed 16-dword payload + CRC32 + END(8'h3C)
TP  : SOF(8'h4B) + {route,type} + {seq,retry,blk,in_req} + CRC5 + END
Transaction packet types: ACK(4'hA) / NRDY(4'h5) / LBAD(4'hB)
* Sequence-number retransmission management: bad DPP CRC32 -> LBAD ->
host resends; duplicate seq -> ACK with retry flag; out-of-order seq
-> NRDY; device IN data retransmitted on LBAD / ACK timeout.
* Function unit: bulk OUT writes / bulk IN reads a 64x32 buffer
(4 blocks x 16 dwords, one DPP carries exactly one block).
Open IP design implementation v2.3 -- Apache-2.0

## Package contents

- `rtl/USB3_top.sv` -- synthesizable RTL (top: `USB3_top`)
- `tb/USB3_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/USB3_yosys.ys` -- Yosys synthesis script
- `syn/USB3_dc.tcl` -- Synopsys Design Compiler script
- `syn/USB3.sdc` -- timing constraints
- `sim/filelist_USB3.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
