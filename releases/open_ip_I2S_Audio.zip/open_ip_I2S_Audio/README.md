# I2S_Audio Open IP

I2S Audio protocol Open IP -- I2S transceiver (TX + RX, master/slave)
Three serial formats (I2S standard / left-justified / right-justified) x
three sample depths (16/24/32 bit) inside a 32-bclk channel slot; TX and
RX operate simultaneously (full-duplex, TB loopback).
Open IP design implementation v2.3 -- Apache-2.0
----------------------------------------------------------------------------
Documented simplifications:
- clk is the master clock (mclk). In master mode bclk = clk / MCLK_DIV
(default 4 -> 256x fs for 32-bit stereo) and wclk(lrck) = bclk / 64.
- All serial logic advances one wire bit per bclk rising tick; the bclk
falling edge is not used (educational single-edge model).
- Parallel sample interface carries both channels per frame
(tx_l/tx_r with valid/ready; rx_l/rx_r with rx_valid frame strobe).
Samples are LSB-aligned on the parallel side and left-justified into
the 32-bit wire slot internally.
- Slave mode: bclk_in/wclk_in must be synchronous to clk (TB drives them
from clk); the receiver re-synchronizes its frame position to every
wclk edge and flags a frame-sync error (irq pulse) when the bclk/wclk
phase is broken (e.g. a dropped bclk pulse).
- TX underrun (no fresh sample at frame start) transmits zeros.
- cfg_fmt/cfg_depth/cfg_master are configuration-register style inputs;
changing them re-synchronizes the frame counters.

## Package contents

- `rtl/I2S_Audio_top.sv` -- synthesizable RTL (top: `I2S_Audio_top`)
- `tb/I2S_Audio_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/I2S_Audio_yosys.ys` -- Yosys synthesis script
- `syn/I2S_Audio_dc.tcl` -- Synopsys Design Compiler script
- `syn/I2S_Audio.sdc` -- timing constraints
- `sim/filelist_I2S_Audio.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
