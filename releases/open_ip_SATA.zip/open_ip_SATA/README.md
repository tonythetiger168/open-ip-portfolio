# SATA Open IP

SATA protocol Open IP -- SATA host: OOB bring-up (COMRESET / COMINIT /
COMWAKE burst-idle patterns + ALIGNp) and FIS transport (SOFp .. CRC32 ..
EOFp). Implements Register H2D commands IDENTIFY (8'hEC), READ DMA EXT
(8'h25) and WRITE DMA EXT (8'h35) against an internal 64x32-bit sector
buffer. In loopback the DUT plays host and device simultaneously.
-- Apache-2.0
Open IP design implementation v2.4
Simplifications (per SPEC):
* refclk is kept for interface compatibility only; the line symbol rate is
1 bit per clk and all logic runs on clk.
* OOB signalling is modelled as burst/idle count patterns on tx_p/rx_p:
COMRESET / COMINIT : 2 x ( 64 clk low burst + 192 clk high idle )
COMWAKE            : 2 x ( 16 clk low burst +  48 clk high idle )
The receiver counts consecutive low symbols: >=48 -> long burst,
8..47 -> short burst; two equal bursts in a row raise the detect event.
* Host command interface (the port contract has no bus): internal
hold-registers host_req / host_cmd / host_lba / hw0..hw3 are poked from
TB via hierarchical references (same observability model as eMMC IP).

## Package contents

- `rtl/SATA_top.sv` -- synthesizable RTL (top: `SATA_top`)
- `tb/SATA_tb.sv` -- self-checking testbench (prints `TEST PASSED`)
- `syn/SATA_yosys.ys` -- Yosys synthesis script
- `syn/SATA_dc.tcl` -- Synopsys Design Compiler script
- `syn/SATA.sdc` -- timing constraints
- `sim/filelist_SATA.f` -- simulator file list
- `Makefile` -- sim / syn entry points

## Quick start

```sh
make sim   # compile + run testbench with iverilog, expect TEST PASSED
make syn   # synthesize with yosys (results land in work/)
```

Prerequisites: `iverilog` and `yosys` on PATH.

> v2.3: I2C P0 fix; ram_style="block" on large memories; BIT_CLKS parameterized serial bit rate. Verified: iverilog sim + yosys syn PASS.
